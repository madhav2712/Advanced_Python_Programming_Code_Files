# campus/ch06_mistake_late_config.py
import logging
from pathlib import Path

Path("campus.log").unlink(missing_ok=True)

logging.warning("import started")
logging.basicConfig(filename="campus.log", level=logging.INFO)
logging.info("line 1 accepted")
logging.warning("line 2 skipped")

print("campus.log exists:", Path("campus.log").exists())

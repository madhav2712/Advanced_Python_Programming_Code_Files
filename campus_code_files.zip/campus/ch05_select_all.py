# campus/ch05_select_all.py
import mysql.connector

connection = mysql.connector.connect(
    host="localhost", user="campus", password="campus123", database="college"
)
cursor = connection.cursor()

cursor.execute("SELECT roll, name, division FROM students ORDER BY roll")
rows = cursor.fetchall()

print("columns:", cursor.column_names)
print("rows returned:", cursor.rowcount)
print("first row:", rows[0], type(rows[0]).__name__)
for roll, name, division in rows:
    print(f"{roll}  {name:<15}{division}")

cursor.close()
connection.close()

# campus/ch09_pandas_inside.py
import pandas as pd

df = pd.read_csv("class_marks.csv", dtype={"roll": str})
column = df["python"]
print(type(df).__name__, "->", type(column).__name__, "->", type(column.to_numpy()).__name__)
print("index:", df.index)
print("columns:", df.columns.tolist())

groups = df.groupby("division")
print(type(groups).__name__)
for key, part in groups:                 # the split step
    print("group", key, "->", part["roll"].tolist())
print(groups["python"].mean())           # apply mean() to each group, combine into a Series

for cls in (pd.DataFrame, pd.Series):
    print(cls.__name__, "MRO:", " -> ".join(c.__name__ for c in cls.__mro__))
for name in ("mean", "to_numpy", "__add__", "head", "loc"):
    owner = next(c for c in pd.Series.__mro__ if name in vars(c))
    print(f"{name:9} is found in {owner.__name__}")

# campus/ch05_create_database.py
import mysql.connector

connection = mysql.connector.connect(host="localhost", user="campus", password="campus123")
cursor = connection.cursor()

cursor.execute("CREATE DATABASE IF NOT EXISTS college")

cursor.execute("SHOW DATABASES")
for (name,) in cursor:
    print(name)

cursor.close()
connection.close()

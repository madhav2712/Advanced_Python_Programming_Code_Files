# campus/ch05_mistake_unread_result.py
import mysql.connector

connection = mysql.connector.connect(
    host="localhost", user="campus", password="campus123", database="college"
)
cursor = connection.cursor()

cursor.execute("SELECT roll, name FROM students ORDER BY roll")
print("first student:", cursor.fetchone())

cursor.execute("SELECT COUNT(*) FROM marks")
print(cursor.fetchone())

cursor.close()
connection.close()

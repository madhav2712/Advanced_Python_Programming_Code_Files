# campus/ch03_super_chain.py
class Person:
    def __init__(self, name, **rest):
        print("  Person.__init__")
        super().__init__(**rest)
        self.name = name


class Learner(Person):
    def __init__(self, roll, **rest):
        print("  Learner.__init__")
        super().__init__(**rest)
        self.roll = roll


class Employee(Person):
    def __init__(self, staff_id, **rest):
        print("  Employee.__init__")
        super().__init__(**rest)
        self.staff_id = staff_id


class LabAssistant(Learner, Employee):
    def __init__(self, hours, **rest):
        print("  LabAssistant.__init__")
        super().__init__(**rest)
        self.hours = hours


print([cls.__name__ for cls in LabAssistant.mro()])
print("creating a lab assistant:")
meera = LabAssistant(hours=6, roll="21", staff_id="LA-03", name="Meera Iyer")
print(meera.name, meera.roll, meera.staff_id, meera.hours)

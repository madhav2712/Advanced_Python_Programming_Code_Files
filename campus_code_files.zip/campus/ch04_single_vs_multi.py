# campus/ch04_single_vs_multi.py
import threading
import time

students = ["Aisha Khan", "Rohan Patil", "Meera Iyer", "Farhan Shaikh"]


def send_notice(name):
    time.sleep(1)             # waiting, not computing


start = time.perf_counter()
for name in students:
    send_notice(name)
print(f"single tasking : {time.perf_counter() - start:.2f} s")

start = time.perf_counter()
threads = [threading.Thread(target=send_notice, args=(name,)) for name in students]
for t in threads:
    t.start()
for t in threads:
    t.join()
print(f"multitasking   : {time.perf_counter() - start:.2f} s")

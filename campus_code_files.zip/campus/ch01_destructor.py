# campus/ch01_destructor.py
class Student:
    def __init__(self, roll, name):
        self.roll = roll
        self.name = name
        print("created", self.roll)

    def __del__(self):
        print("finalised", self.roll)


aisha = Student("12", "Aisha Khan")
monitor = aisha            # a second name for the same object

del aisha
print("after del aisha")
del monitor
print("after del monitor")

# campus/ch06_logical_error.py
def grade(percent):
    if percent >= 75:
        return "Distinction"
    if percent >= 60:
        return "First Class"
    if percent > 40:
        return "Pass"
    return "Fail"


for name, percent in [("Aisha Khan", 78.0), ("Rohan Patil", 61.5), ("Farhan Shaikh", 40.0)]:
    print(f"{name:<15}{percent:>6}  {grade(percent)}")

assert grade(40.0) == "Pass", "a student with exactly 40 per cent must pass"
print("all checks passed")

# campus/ch05_insert_rows.py
import mysql.connector

connection = mysql.connector.connect(
    host="localhost", user="campus", password="campus123", database="college"
)
cursor = connection.cursor()

add_student = "INSERT INTO students (roll, name, division) VALUES (%s, %s, %s)"
students = [
    ("12", "Aisha Khan", "A"),
    ("07", "Rohan Patil", "A"),
    ("21", "Meera Iyer", "B"),
    ("15", "Farhan Shaikh", "B"),
]
for student in students:
    cursor.execute(add_student, student)
    print("inserted", student[1], "- rows affected:", cursor.rowcount)

# No division given, so the column's DEFAULT 'A' is used.
cursor.execute("INSERT INTO students (roll, name) VALUES (%s, %s)", ("40", "Kabir Joshi"))

add_mark = "INSERT INTO marks (roll, subject, obtained, maximum) VALUES (%s, %s, %s, %s)"
marks = [
    ("12", "Python", 78, 100), ("12", "Statistics", 72, 100), ("12", "Python Lab", 41, 50),
    ("07", "Python", 64, 100), ("07", "Statistics", 70, 100), ("07", "Python Lab", 35, 50),
    ("21", "Python", 91, 100), ("21", "Statistics", 84, 100), ("21", "Python Lab", 47, 50),
    ("15", "Python", 38, 100), ("15", "Statistics", 30, 100), ("15", "Python Lab", 22, 50),
    ("40", "Python", 66, 100),
]
cursor.executemany(add_mark, marks)
print("mark rows inserted by executemany():", cursor.rowcount)

connection.commit()
print("committed")

cursor.close()
connection.close()

# campus/ch04_race_condition.py
import threading
import time


class LabSlots:
    def __init__(self, seats):
        self.seats = seats
        self.booked = []

    def book(self, name):
        if self.seats > 0:                # check ...
            time.sleep(0.01)              # ... a short gap ...
            self.seats -= 1               # ... then act
            self.booked.append(name)


lab = LabSlots(seats=2)
names = ["Aisha", "Rohan", "Meera", "Farhan", "Kabir"]
threads = [threading.Thread(target=lab.book, args=(n,)) for n in names]
for t in threads:
    t.start()
for t in threads:
    t.join()
print("booked:", len(lab.booked), lab.booked)
print("seats left:", lab.seats)

# campus/ch04_create_method.py
import threading
import time


class AttendanceCounter:                  # an ordinary class, not a Thread
    def __init__(self, room):
        self.room = room
        self.present = 0

    def scan(self, cards):
        for card in cards:
            time.sleep(0.05)
            self.present += 1
        print(f"{self.room}: {self.present} present")


lab1 = AttendanceCounter("Lab 1")
lab2 = AttendanceCounter("Lab 2")
threads = [
    threading.Thread(target=lab1.scan, args=(["12", "07", "21"],)),
    threading.Thread(target=lab2.scan, args=(["15"],)),
]
for t in threads:
    t.start()
for t in threads:
    t.join()
print("Lab 1 + Lab 2 =", lab1.present + lab2.present)

# campus/ch09_numpy_broadcast.py
import numpy as np

marks = np.loadtxt("class_marks.csv", delimiter=",", skiprows=1, usecols=(3, 4, 5), dtype=int)
maximum = np.array([100, 100, 50])       # Python, Statistics, Lab
print("shapes:", marks.shape, "and", maximum.shape)

percent = marks / maximum * 100          # every row is divided by the same three maxima
print(percent[:3])

overall = marks.sum(axis=1) / maximum.sum() * 100
grade = np.select([overall >= 75, overall >= 60, overall >= 40],
                  ["Distinction", "First Class", "Pass"], default="Fail")
print(overall.round(1))
print(grade)

names, counts = np.unique(grade, return_counts=True)
print(dict(zip(names.tolist(), counts.tolist())))

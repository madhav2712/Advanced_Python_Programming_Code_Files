# campus/ch05_mistake_no_commit.py
import mysql.connector

settings = dict(host="localhost", user="campus", password="campus123", database="college")

first = mysql.connector.connect(**settings)
cursor = first.cursor()
cursor.execute("INSERT INTO students (roll, name) VALUES (%s, %s)", ("33", "Neha Rao"))
print("rows affected:", cursor.rowcount)
cursor.close()
first.close()                       # closed without commit()

second = mysql.connector.connect(**settings)
cursor = second.cursor()
cursor.execute("SELECT COUNT(*) FROM students WHERE roll = %s", ("33",))
print("rows for roll 33 after reconnecting:", cursor.fetchone()[0])
cursor.close()
second.close()

# campus/ch01_new_init_trace.py
class Student:
    def __new__(cls, roll, name):
        print("1. __new__ makes an empty", cls.__name__, "object")
        return object.__new__(cls)

    def __init__(self, roll, name):
        print("2. __init__ fills in its attributes")
        self.roll = roll
        self.name = name


aisha = Student("12", "Aisha Khan")
print("3. the name aisha now refers to it:", aisha.roll, aisha.name)

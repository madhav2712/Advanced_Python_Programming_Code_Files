# campus/ch09_problem_lists.py
import csv
import time

with open("class_marks.csv", newline="") as file:
    rows = list(csv.DictReader(file))

# The percentage of every student: one loop.
percents = []
for row in rows:
    total = int(row["python"]) + int(row["statistics"]) + int(row["lab"])
    percents.append(total / 250 * 100)

# The average percentage of each division: another loop and two dictionaries.
sums, counts = {}, {}
for row, percent in zip(rows, percents):
    division = row["division"]
    sums[division] = sums.get(division, 0) + percent
    counts[division] = counts.get(division, 0) + 1
for division in sorted(sums):
    print(f"division {division}: {counts[division]} students, average {sums[division] / counts[division]:.1f}%")

# The same formula for one million marks, as a university might have.
marks = [n % 251 for n in range(1_000_000)]
start = time.perf_counter()
result = [mark / 250 * 100 for mark in marks]
print(f"one million percentages with a list: {time.perf_counter() - start:.3f} seconds")

# campus/ch02_problem_args.py
def print_row(roll, name, python, stats, networks):
    total = python + stats + networks
    print(f"{roll:>4} {name:<15}{python:>4}{stats:>4}{networks:>4}{total:>5}")


print_row("12", "Aisha Khan", 78, 72, 81)
print_row("Rohan Patil", "07", 64, 70, 58)
print_row("21", "Meera Iyer", 84, 91, 88)

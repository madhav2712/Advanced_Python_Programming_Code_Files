# campus/ch04_problem_sequential.py
import time


def send_notice(name):
    time.sleep(1)             # stands in for waiting on the mail server
    print("notice sent to", name)


start = time.perf_counter()
for name in ["Aisha Khan", "Rohan Patil", "Meera Iyer", "Farhan Shaikh"]:
    send_notice(name)
print(f"time taken: {time.perf_counter() - start:.1f} s")

# campus/ch04_cpu_bound.py
import sys
import threading
import time


def count_up(n):
    total = 0
    for i in range(n):
        total += i
    return total


N = 5_000_000
print("GIL enabled:", sys._is_gil_enabled())

start = time.perf_counter()
count_up(N)
count_up(N)
print(f"one thread, two jobs : {time.perf_counter() - start:.2f} s")

start = time.perf_counter()
threads = [threading.Thread(target=count_up, args=(N,)) for _ in range(2)]
for t in threads:
    t.start()
for t in threads:
    t.join()
print(f"two threads          : {time.perf_counter() - start:.2f} s")

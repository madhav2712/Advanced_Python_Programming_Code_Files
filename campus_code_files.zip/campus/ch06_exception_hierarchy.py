# campus/ch06_exception_hierarchy.py
class CampusError(Exception):
    """Base class for every error that the Campus Toolkit raises."""


class InvalidMarkError(CampusError):
    def __init__(self, roll, subject, obtained, maximum):
        super().__init__(f"roll {roll}: {obtained} is outside 0 to {maximum} in {subject}")
        self.roll = roll
        self.obtained = obtained
        self.maximum = maximum


class UnknownStudentError(CampusError):
    def __init__(self, roll):
        super().__init__(f"no student has roll {roll}")
        self.roll = roll


students = {"07": "Rohan Patil", "12": "Aisha Khan", "15": "Farhan Shaikh", "21": "Meera Iyer"}


def record_mark(roll, subject, obtained, maximum=100):
    if roll not in students:
        raise UnknownStudentError(roll)
    if not 0 <= obtained <= maximum:
        raise InvalidMarkError(roll, subject, obtained, maximum)
    print("recorded:", students[roll], subject, obtained)


entries = [("12", "Python", 81), ("15", "Python", 105), ("33", "Python", 55), ("21", "Python Lab", 49, 50)]
for entry in entries:
    try:
        record_mark(*entry)
    except InvalidMarkError as error:
        print("roll", error.roll, "- please re-enter the mark; the maximum is", error.maximum)
    except CampusError as error:
        print(type(error).__name__ + ":", error)

error = UnknownStudentError("33")
print("args:", error.args, " roll:", error.roll, " is a CampusError:", isinstance(error, CampusError))

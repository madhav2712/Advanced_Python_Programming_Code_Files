# campus/ch03_method_overloading.py
class Student:
    def __init__(self, marks):
        self.marks = marks

    def total(self, best_of=None):
        chosen = sorted(self.marks, reverse=True)
        if best_of is not None:
            chosen = chosen[:best_of]
        return sum(chosen)

    def add_marks(self, *new_marks):
        self.marks.extend(new_marks)
        return len(self.marks)


meera = Student([84, 91, 47, 76])
print(meera.total(), meera.total(3), meera.total(best_of=2))
print(meera.add_marks(88), meera.add_marks(70, 65))
print(meera.total())

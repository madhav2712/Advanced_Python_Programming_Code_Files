# campus/ch02_datetime_example.py
from datetime import date, datetime, time

exam_day = date.fromisoformat("2026-11-16")     # class method builds a date
start = time(10, 30)
paper = datetime.combine(exam_day, start)       # objects of two classes go in

print(type(exam_day).__name__, type(start).__name__, type(paper).__name__)
print(paper)
print(paper.strftime("%d %B %Y, %I:%M %p"))

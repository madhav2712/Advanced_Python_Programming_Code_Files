# campus/ch05_insert_rejected.py
import mysql.connector

connection = mysql.connector.connect(
    host="localhost", user="campus", password="campus123", database="college"
)
cursor = connection.cursor()

bad_rows = [
    ("INSERT INTO students (roll, name) VALUES (%s, %s)", ("12", "Aisha K.")),
    ("INSERT INTO marks (roll, subject, obtained) VALUES (%s, %s, %s)", ("07", "Networks", 105)),
    ("INSERT INTO marks (roll, subject, obtained) VALUES (%s, %s, %s)", ("99", "Python", 50)),
]

for query, values in bad_rows:
    try:
        cursor.execute(query, values)
    except mysql.connector.Error as error:
        print("refused:", values)
        print("  ", error.errno, error.msg)

cursor.execute("SELECT COUNT(*) FROM students")
print("students still stored:", cursor.fetchone()[0])

cursor.close()
connection.close()

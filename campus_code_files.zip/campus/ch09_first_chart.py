# campus/ch09_first_chart.py
import matplotlib.pyplot as plt
import numpy as np

names = ["Rohan", "Aisha", "Farhan", "Meera"]
totals = np.array([173, 191, 92, 224])

fig, ax = plt.subplots(figsize=(6, 3.5), layout="constrained")   # one Figure with one Axes
ax.bar(names, totals, color="steelblue")
ax.axhline(100, color="red", linestyle="--", label="pass line: 100 of 250")
ax.set_title("Term II totals")
ax.set_xlabel("Student")
ax.set_ylabel("Total out of 250")
ax.set_ylim(0, 250)
ax.legend()

fig.savefig("chart_totals.png", dpi=150)
print(type(fig).__name__, "with", len(fig.axes), "Axes, saved as chart_totals.png")

# campus/ch08_problem_console.py
TOTALS = {"07": 173, "12": 191, "15": 92, "21": 224}

print("Exam cell result desk")
roll = int(input("Roll number: "))
total = TOTALS[f"{roll:02d}"]
print(f"Roll {roll:02d}: {total} out of 250")

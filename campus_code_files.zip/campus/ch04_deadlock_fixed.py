# campus/ch04_deadlock_fixed.py
import threading
import time

rank_lock = threading.Lock()              # rule: always take rank_lock first
log_lock = threading.Lock()


def update_ranks():
    with rank_lock:
        print("ranker: holding rank_lock")
        time.sleep(0.1)
        with log_lock:
            print("ranker: done")


def write_log():
    with rank_lock:                       # same order as update_ranks
        print("logger: holding rank_lock")
        time.sleep(0.1)
        with log_lock:
            print("logger: done")


ranker = threading.Thread(target=update_ranks, daemon=True)
logger = threading.Thread(target=write_log, daemon=True)
ranker.start()
logger.start()
ranker.join(timeout=2)
logger.join(timeout=2)
print("after joins -> ranker alive:", ranker.is_alive(), "| logger alive:", logger.is_alive())

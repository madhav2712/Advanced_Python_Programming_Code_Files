# campus/ch08_place.py
import tkinter as tk

root = tk.Tk()
root.title("Admit card")
root.geometry("320x170")

tk.Label(root, text="ADMIT CARD", font=("Arial", 12, "bold")).place(relx=0.5, y=10, anchor="n")
tk.Label(root, text="Roll 12  Aisha Khan\nTerm II examination",
         justify="left").place(x=15, y=50)
tk.Label(root, text="Photo", relief="solid", width=8, height=4).place(
    relx=1.0, x=-15, y=45, anchor="ne")
tk.Label(root, text="Exam cell seal", fg="darkred").place(
    relx=1.0, rely=1.0, x=-10, y=-10, anchor="se")

root.mainloop()

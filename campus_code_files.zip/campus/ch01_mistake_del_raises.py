# campus/ch01_mistake_del_raises.py
class Student:
    def __init__(self, roll):
        self.roll = roll

    def __del__(self):
        print("saving", self.roll, "to", self.backup_file)


farhan = Student("15")
del farhan
print("the program carries on")

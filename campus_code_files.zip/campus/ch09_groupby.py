# campus/ch09_groupby.py
import numpy as np
import pandas as pd

df = pd.read_csv("class_marks.csv", dtype={"roll": str})
df["percent"] = (df[["python", "statistics", "lab"]].sum(axis=1) / 250 * 100).round(1)
df["grade"] = np.select([df["percent"] >= 75, df["percent"] >= 60, df["percent"] >= 40],
                        ["Distinction", "First Class", "Pass"], default="Fail")

print(df.groupby("division")[["python", "statistics", "lab", "percent"]].mean().round(1))
print(df.groupby("division")["percent"].agg(["count", "min", "max"]))
print(pd.crosstab(df["division"], df["grade"]))

df.to_csv("class_results.csv", index=False)
print("saved class_results.csv:", len(df), "rows,", len(df.columns), "columns")

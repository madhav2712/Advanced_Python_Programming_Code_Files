# campus/ch03_constructors_inheritance.py
class Learner:
    def __init__(self, roll, name):
        print("  Learner.__init__ runs")
        self.roll = roll
        self.name = name


class ExternalStudent(Learner):
    pass                                     # no __init__ here: the parent's is used


class RegularStudent(Learner):
    def __init__(self, roll, name, internal):
        print("  RegularStudent.__init__ runs")
        super().__init__(roll, name)         # build the parent part first
        self.internal = internal


print("ExternalStudent(...):")
kabir = ExternalStudent("40", "Kabir Joshi")
print(" ", kabir.roll, kabir.name)

print("RegularStudent(...):")
aisha = RegularStudent("12", "Aisha Khan", 21)
print(" ", aisha.roll, aisha.name, aisha.internal)

# campus/ch08_pack.py
import tkinter as tk

root = tk.Tk()
root.title("Notice board")

tk.Label(root, text="Exam Cell Notice Board", bg="#1f4e79", fg="white",
         pady=6).pack(side="top", fill="x")
tk.Label(root, text="Updated by the exam cell", bg="#d9d9d9").pack(side="bottom", fill="x")
tk.Label(root, text="Results\nTimetable\nRules", bg="#f2d7a6", width=10,
         justify="left").pack(side="left", fill="y")
tk.Label(root, text="Term II results are out.\nCollect mark sheets from Counter 3.",
         bg="white", padx=10, pady=10).pack(side="left", fill="both", expand=True)

root.mainloop()

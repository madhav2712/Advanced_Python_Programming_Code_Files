# campus/ch04_mistake_forgot_release.py
import threading

lock = threading.Lock()
marks = {}


def save_mark(roll, mark):
    lock.acquire()
    if not 0 <= mark <= 100:
        print("bad mark for", roll, "- returning early")
        return                            # the lock is never released
    marks[roll] = mark
    lock.release()


save_mark("15", 120)
t = threading.Thread(target=save_mark, args=("12", 78), daemon=True)
t.start()
t.join(timeout=1)
print("second save still waiting?", t.is_alive(), "| marks:", marks)

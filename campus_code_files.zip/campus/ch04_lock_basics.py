# campus/ch04_lock_basics.py
import threading

lock = threading.Lock()

lock.acquire()
print("after acquire :", lock.locked())
lock.release()
print("after release :", lock.locked())

with lock:
    print("inside with   :", lock.locked())
print("after with    :", lock.locked())

print("acquire when free, wait up to 0.5 s:", lock.acquire(timeout=0.5))
print("acquire while held, wait up to 0.5 s:", lock.acquire(timeout=0.5))

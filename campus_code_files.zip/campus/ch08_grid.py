# campus/ch08_grid.py
import tkinter as tk

root = tk.Tk()
root.title("Marks entry")

fields = ["Roll number", "Name", "Python (out of 100)", "Statistics (out of 100)"]
for row, text in enumerate(fields):
    tk.Label(root, text=text).grid(row=row, column=0, sticky="w", padx=(10, 5), pady=4)
    tk.Entry(root, width=20).grid(row=row, column=1, sticky="ew", padx=(0, 10), pady=4)

tk.Button(root, text="Save").grid(row=len(fields), column=0, columnspan=2, pady=8)
root.columnconfigure(1, weight=1)

root.mainloop()

# campus/ch07_ftp_server.py
import logging
import threading
from pathlib import Path

from pyftpdlib.authorizers import DummyAuthorizer
from pyftpdlib.handlers import FTPHandler
from pyftpdlib.servers import FTPServer

ROOT = Path("ftp_root")
ROOT.mkdir(exist_ok=True)
(ROOT / "timetable.txt").write_text(
    "Mon 10:00 Python\nTue 11:00 Statistics\nWed 14:00 Python Lab\n", encoding="utf-8")


class CampusHandler(FTPHandler):
    banner = "Campus practice FTP server ready."
    passive_ports = [2122]

    def on_login(self, username):
        print("server:", username, "logged in")

    def on_login_failed(self, username, password):
        print("server: wrong password for", username)

    def on_file_sent(self, file):
        print("server: sent", Path(file).name)

    def on_file_received(self, file):
        print("server: received", Path(file).name)

    def on_logout(self, username):
        print("server:", username, "logged out")


logging.basicConfig(level=logging.WARNING)
authorizer = DummyAuthorizer()
authorizer.add_user("campus", "campus123", str(ROOT), perm="elrw")
CampusHandler.authorizer = authorizer

server = FTPServer(("127.0.0.1", 2121), CampusHandler)
threading.Thread(target=server.serve_forever, daemon=True).start()
print("server: FTP control connection on 127.0.0.1 port 2121")
input("server: press Enter to stop\n")
print("server: stopped")

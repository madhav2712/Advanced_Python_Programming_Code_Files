# campus/ch09_scipy_fit.py
import matplotlib.pyplot as plt
import numpy as np
from scipy.optimize import curve_fit

weeks = np.arange(1, 9)
average = np.array([4.1, 5.2, 5.8, 6.4, 6.6, 6.9, 7.1, 7.1])   # the quiz averages of Program 9.8


def learning(t, a, b, c):
    return a - b * np.exp(-c * t)


params, covariance = curve_fit(learning, weeks, average, p0=[8, 5, 0.3])
a, b, c = params
print(f"a = {a:.2f}, b = {b:.2f}, c = {c:.3f}")
print(f"expected average in week 12: {learning(12, *params):.2f}")

fig, ax = plt.subplots(figsize=(6, 3.5), layout="constrained")
ax.plot(weeks, average, "o", label="quiz average")
later = np.linspace(1, 12, 100)
ax.plot(later, learning(later, *params), label="fitted curve")
ax.axhline(a, color="grey", linestyle=":", label=f"level a = {a:.2f}")
ax.set_title("Quiz averages and the fitted curve")
ax.set_xlabel("Week")
ax.set_ylabel("Average mark out of 10")
ax.set_ylim(0, 10)
ax.legend(loc="lower right")
fig.savefig("chart_fit.png", dpi=150)
print("saved chart_fit.png")

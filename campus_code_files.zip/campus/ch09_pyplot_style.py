# campus/ch09_pyplot_style.py
import matplotlib.pyplot as plt

weeks = [1, 2, 3, 4, 5, 6, 7, 8]
average = [4.1, 5.2, 5.8, 6.4, 6.6, 6.9, 7.1, 7.1]    # class average in each weekly quiz, out of 10

plt.figure(figsize=(6, 3.5), layout="constrained")
plt.plot(weeks, average, marker="o")
plt.title("Weekly Python quiz: class average")
plt.xlabel("Week")
plt.ylabel("Average mark out of 10")
plt.ylim(0, 10)
plt.grid(True)
plt.savefig("chart_quiz.png", dpi=150)

print("current figure:", plt.gcf())
print("title of the current Axes:", plt.gca().get_title())

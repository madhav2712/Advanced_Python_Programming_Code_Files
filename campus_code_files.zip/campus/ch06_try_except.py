# campus/ch06_try_except.py
entries = ["12,81", "07,6O", "21,94", "15,47"]

total = 0
counted = 0
for entry in entries:
    roll, mark = entry.split(",")
    try:
        total += int(mark)
    except ValueError as error:
        print("skipped roll", roll, "-", error)
        continue
    counted += 1
    print("added roll", roll, "mark", mark)

print("marks counted:", counted, "of", len(entries))
print("class average:", round(total / counted, 1))

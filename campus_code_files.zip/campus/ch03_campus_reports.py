# campus/ch03_campus_reports.py
from abc import ABC, abstractmethod


class Score:
    def __init__(self, obtained, maximum):
        self.obtained = obtained
        self.maximum = maximum

    def percent(self):
        return round(self.obtained / self.maximum * 100, 1)

    def __add__(self, other):
        if not isinstance(other, Score):
            return NotImplemented
        return Score(self.obtained + other.obtained, self.maximum + other.maximum)

    def __radd__(self, other):
        return self if other == 0 else NotImplemented

    def __lt__(self, other):
        return self.percent() < other.percent()

    def __str__(self):
        return f"{self.obtained}/{self.maximum} ({self.percent()}%)"


class Learner(ABC):
    def __init__(self, roll, name):
        self.roll = roll
        self.name = name

    @abstractmethod
    def score(self):
        pass


class RegularStudent(Learner):
    def __init__(self, roll, name, internal, external):
        super().__init__(roll, name)
        self.internal = Score(internal, 25)
        self.external = Score(external, 75)

    def score(self):
        return self.internal + self.external


class ExternalStudent(Learner):
    def __init__(self, roll, name, external):
        super().__init__(roll, name)
        self.external = Score(external, 75)

    def score(self):
        return self.external


class ReportWriter(ABC):
    @abstractmethod
    def header(self):
        pass

    @abstractmethod
    def row(self, rank, learner):
        pass

    def write(self, learners):
        ranked = sorted(learners, key=by_score, reverse=True)
        print(self.header())
        for rank, learner in enumerate(ranked, start=1):
            print(self.row(rank, learner))


class TextReport(ReportWriter):
    def header(self):
        return "Rank Roll  Name            Score"

    def row(self, rank, learner):
        return f"{rank:>4} {learner.roll:>4}  {learner.name:<15} {learner.score()}"


def by_score(learner):
    return learner.score()


batch = [
    RegularStudent("12", "Aisha Khan", 21, 58),
    RegularStudent("07", "Rohan Patil", 18, 49),
    RegularStudent("21", "Meera Iyer", 24, 66),
    RegularStudent("15", "Farhan Shaikh", 12, 27),
    ExternalStudent("40", "Kabir Joshi", 61),
]
TextReport().write(batch)
print("Division total:", sum(learner.score() for learner in batch))

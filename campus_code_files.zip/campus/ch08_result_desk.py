# campus/ch08_result_desk.py
import tkinter as tk

STUDENTS = {
    "07": ("Rohan Patil", 173),
    "12": ("Aisha Khan", 191),
    "15": ("Farhan Shaikh", 92),
    "21": ("Meera Iyer", 224),
}
MAXIMUM = 250


def grade(percent):
    if percent >= 75:
        return "Distinction"
    if percent >= 60:
        return "First Class"
    if percent >= 40:
        return "Pass"
    return "Fail"


class ResultDesk(tk.Frame):
    def __init__(self, master):
        super().__init__(master, padx=10, pady=10)
        master.title("Exam Cell Result Desk")
        self.shown = 0

        tk.Label(self, text="Students").grid(row=0, column=0, sticky="w")
        self.students = tk.Listbox(self, height=5, width=20)
        for roll, (name, _) in STUDENTS.items():
            self.students.insert("end", f"{roll}  {name}")
        self.students.grid(row=1, column=0, rowspan=2, sticky="ns", padx=(0, 10))

        tk.Label(self, text="Roll number").grid(row=0, column=1, sticky="w")
        self.roll = tk.Entry(self, width=10)
        self.roll.grid(row=1, column=1, sticky="nw")
        tk.Button(self, text="Show result", command=self.show).grid(
            row=1, column=2, sticky="nw", padx=(5, 0))
        self.result = tk.Label(self, text="Type a roll number, or double-click a name.",
                               width=44, anchor="w", justify="left")
        self.result.grid(row=2, column=1, columnspan=2, sticky="nw")
        self.columnconfigure(2, weight=1)

        self.status = tk.Label(master, text="Results shown: 0", anchor="w",
                               relief="sunken", padx=5)
        self.roll.bind("<Return>", self.show)
        self.students.bind("<Double-Button-1>", self.pick)
        self.roll.focus_set()

    def show(self, event=None):
        text = self.roll.get().strip()
        try:
            name, total = STUDENTS[f"{int(text):02d}"]
        except ValueError:
            self.report(f"'{text}' is not a roll number. Type digits only.", "red")
            return
        except KeyError:
            self.report(f"No student has roll number {text}.", "red")
            return
        percent = round(total / MAXIMUM * 100, 1)
        self.report(f"{name}: {total} out of {MAXIMUM}, {percent} per cent, "
                    f"{grade(percent)}", "darkgreen")
        self.shown += 1
        self.status.config(text=f"Results shown: {self.shown}")

    def pick(self, event):
        line = self.students.get(self.students.nearest(event.y))
        self.roll.delete(0, "end")
        self.roll.insert(0, line[:2])
        self.show()

    def report(self, message, colour):
        self.result.config(text=message, fg=colour)
        print(message)


if __name__ == "__main__":
    root = tk.Tk()
    desk = ResultDesk(root)
    desk.pack(fill="both", expand=True)
    desk.status.pack(fill="x")
    root.mainloop()

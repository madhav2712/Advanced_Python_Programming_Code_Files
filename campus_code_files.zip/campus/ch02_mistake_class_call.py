# campus/ch02_mistake_class_call.py
class ResultSheet:
    def __init__(self, title):
        self.title = title
        self.rows = []

    def add(self, student):
        self.rows.append(student)


ResultSheet.add("Aisha Khan")

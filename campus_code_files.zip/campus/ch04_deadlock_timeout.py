# campus/ch04_deadlock_timeout.py
import threading
import time

rank_lock = threading.Lock()
log_lock = threading.Lock()


def update_ranks():
    with rank_lock:
        print("ranker: holding rank_lock, wants log_lock")
        time.sleep(0.1)
        with log_lock:
            print("ranker: done")


def write_log():
    with log_lock:
        print("logger: holding log_lock, wants rank_lock")
        time.sleep(0.1)
        if rank_lock.acquire(timeout=1):
            print("logger: done")
            rank_lock.release()
        else:
            print("logger: gave up after 1 s and released log_lock")


ranker = threading.Thread(target=update_ranks)
logger = threading.Thread(target=write_log)
ranker.start()
logger.start()
ranker.join()
logger.join()
print("both threads finished")

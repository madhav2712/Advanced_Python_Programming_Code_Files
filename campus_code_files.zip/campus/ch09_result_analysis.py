# campus/ch09_result_analysis.py
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

SUBJECTS = ["python", "statistics", "lab"]
MAXIMUM = np.array([100, 100, 50])


def load(path):
    df = pd.read_csv(path, dtype={"roll": str})
    empty = df.isna().any(axis=1)
    if empty.any():
        print("left out, because a cell is empty:", df.loc[empty, "roll"].tolist())
    return df[~empty].set_index("roll")


def add_results(df):
    marks = df[SUBJECTS].to_numpy()
    df["percent"] = (marks.sum(axis=1) / MAXIMUM.sum() * 100).round(1)
    df["grade"] = np.select([df["percent"] >= 75, df["percent"] >= 60, df["percent"] >= 40],
                            ["Distinction", "First Class", "Pass"], default="Fail")
    return df


def chart(df, by_division, line, filename):
    fig, (left, right) = plt.subplots(1, 2, figsize=(10, 4), layout="constrained")
    by_division.T.plot(kind="bar", ax=left, rot=0)
    left.set_title("Subject average (% of maximum)")
    left.set_ylim(0, 100)

    for division, part in df.groupby("division"):
        right.scatter(part["attendance"], part["percent"], label=f"division {division}")
    x = np.array([df["attendance"].min(), df["attendance"].max()])
    right.plot(x, line.intercept + line.slope * x, color="grey", label=f"fitted line, r = {line.rvalue:.2f}")
    right.axhline(40, color="red", linestyle="--", label="pass line (40%)")
    right.set_title("Attendance and result")
    right.set_xlabel("Attendance (%)")
    right.set_ylabel("Percentage")
    right.legend()

    fig.savefig(filename, dpi=150)


def main():
    df = add_results(load("class_marks.csv"))
    print(df.sort_values("percent", ascending=False)[["name", "division", "percent", "grade"]])

    by_division = (df.groupby("division")[SUBJECTS].mean() / MAXIMUM * 100).round(1)
    print(by_division)

    line = stats.linregress(df["attendance"], df["percent"])
    print(f"attendance and result: r = {line.rvalue:.2f}, about {line.slope:.2f} percentage points "
          f"more for each extra 1% of attendance")
    print("attendance below 75%:", df.index[df["attendance"] < 75].tolist())

    df.to_csv("class_report.csv")
    chart(df, by_division, line, "class_report.png")
    print("saved class_report.csv and class_report.png")


if __name__ == "__main__":
    main()

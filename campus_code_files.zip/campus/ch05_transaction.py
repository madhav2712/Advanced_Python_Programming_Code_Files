# campus/ch05_transaction.py
import mysql.connector

settings = dict(host="localhost", user="campus", password="campus123", database="college")
office = mysql.connector.connect(**settings)
notice_board = mysql.connector.connect(**settings, autocommit=True)

change = "UPDATE marks SET obtained = %s WHERE roll = %s AND subject = %s"
query = "SELECT obtained FROM marks WHERE roll = %s AND subject = %s"
key = ("15", "Python")


def read(connection, who):
    cursor = connection.cursor()
    cursor.execute(query, key)
    print(f"  {who:<13}sees {cursor.fetchone()[0]}")
    cursor.close()


cursor = office.cursor()

cursor.execute(change, (40, *key))
print("office sets Farhan's Python mark to 40, no commit yet")
read(office, "office")
read(notice_board, "notice board")

office.rollback()
print("office calls rollback()")
read(office, "office")

cursor.execute(change, (41, *key))
office.commit()
print("office sets the mark to 41 and calls commit()")
read(notice_board, "notice board")

cursor.close()
office.close()
notice_board.close()

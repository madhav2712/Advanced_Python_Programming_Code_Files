# campus/ch09_numpy_first.py
import time

import numpy as np

totals = np.array([173, 191, 92, 224])
print("array:", totals)
print("type:", type(totals).__name__, "| dtype:", totals.dtype, "| shape:", totals.shape,
      "| ndim:", totals.ndim, "| size:", totals.size)

percent = totals / 250 * 100            # one expression works on every element
print("percent:", percent)
print("passed:", percent >= 40)          # a comparison gives an array of True and False
print("mean:", percent.mean().round(1), "| highest:", percent.max().round(1), "at index", percent.argmax())

marks = np.arange(1_000_000) % 251      # the same one million marks as Program 9.1
start = time.perf_counter()
result = marks / 250 * 100
print(f"one million percentages with NumPy: {time.perf_counter() - start:.3f} seconds")

# campus/ch07_result_client.py
import smtplib
import socket
from email.message import EmailMessage

SERVICE = ("127.0.0.1", 5052)
MAIL_SERVER = ("127.0.0.1", 8025)


def ask(requests):
    replies = []
    with socket.create_connection(SERVICE, timeout=5) as connection:
        stream = connection.makefile("rw", encoding="utf-8", newline="\n")
        for request in requests:
            stream.write(request + "\n")
            stream.flush()
            reply = stream.readline().rstrip("\n")
            print(f"client: {request:<10} -> {reply}")
            replies.append(reply)
    return replies


def summary(replies):
    lines = ["Term II results, total out of 250:", ""]
    for reply in replies:
        status, _, detail = reply.partition(" ")
        if status == "OK" and detail != "bye":
            lines.append(detail)
    lines += ["", "Exam Cell"]
    message = EmailMessage()
    message["Subject"] = "Term II results, Python class"
    message["From"] = "examcell@campus.example"
    message["To"] = "class.teacher@campus.example"
    message.set_content("\n".join(lines) + "\n")
    return message


try:
    replies = ask(["RESULT 07", "RESULT 12", "RESULT 15", "RESULT 21", "RESULT 33", "BYE"])
except (ConnectionRefusedError, TimeoutError) as error:
    print("client: the results service did not answer:", error)
else:
    message = summary(replies)
    try:
        with smtplib.SMTP(*MAIL_SERVER, timeout=5) as server:
            server.send_message(message)
        print("client: summary mailed to", message["To"])
    except OSError as error:
        print("client: the summary could not be mailed:", error)

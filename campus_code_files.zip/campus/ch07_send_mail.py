# campus/ch07_send_mail.py
import smtplib
from email.message import EmailMessage

message = EmailMessage()
message["Subject"] = "Term II result"
message["From"] = "examcell@campus.example"
message["To"] = "aisha.khan@campus.example"
message.set_content(
    "Dear Aisha,\n\n"
    "Your Term II total is 191 out of 250 (76.4 per cent, Distinction).\n\n"
    "Exam Cell\n")

with smtplib.SMTP("127.0.0.1", 8025, local_hostname="examcell-pc") as server:
    server.set_debuglevel(1)
    refused = server.send_message(message)

print("refused recipients:", refused)

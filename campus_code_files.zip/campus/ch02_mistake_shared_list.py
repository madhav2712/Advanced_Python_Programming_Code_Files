# campus/ch02_mistake_shared_list.py
class Student:
    remarks = []

    def __init__(self, name):
        self.name = name

    def add_remark(self, text):
        self.remarks.append(text)


aisha = Student("Aisha Khan")
rohan = Student("Rohan Patil")
aisha.add_remark("Lab journal submitted")
print(rohan.name, rohan.remarks)

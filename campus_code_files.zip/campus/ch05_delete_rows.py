# campus/ch05_delete_rows.py
import mysql.connector

connection = mysql.connector.connect(
    host="localhost", user="campus", password="campus123", database="college"
)
cursor = connection.cursor()

# Kabir Joshi has withdrawn. His student row still has a mark row pointing to it.
try:
    cursor.execute("DELETE FROM students WHERE roll = %s", ("40",))
except mysql.connector.Error as error:
    print("refused:", error.errno, error.msg)

cursor.execute("DELETE FROM marks WHERE roll = %s", ("40",))
print("mark rows deleted:", cursor.rowcount)
cursor.execute("DELETE FROM students WHERE roll = %s", ("40",))
print("student rows deleted:", cursor.rowcount)

cursor.execute("DELETE FROM students WHERE roll = %s", ("99",))
print("rows deleted for roll 99:", cursor.rowcount)

connection.commit()

cursor.execute("SELECT COUNT(*) FROM students")
print("students now:", cursor.fetchone()[0])

cursor.close()
connection.close()

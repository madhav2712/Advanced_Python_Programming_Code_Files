# campus/ch09_numpy_2d.py
import numpy as np

# Columns 3, 4 and 5 of the file: python, statistics and lab.
marks = np.loadtxt("class_marks.csv", delimiter=",", skiprows=1, usecols=(3, 4, 5), dtype=int)
print("shape:", marks.shape)
print("first three rows:")
print(marks[:3])
print("row 3 (Aisha):", marks[3])
print("column 0 (Python):", marks[:, 0])
print("row 3, column 1 (Aisha's Statistics):", marks[3, 1])

totals = marks.sum(axis=1)               # along each row: one total per student
print("totals:", totals)
print("subject averages:", marks.mean(axis=0).round(1))   # down each column

weak = marks[:, 0] < 50                  # True where the Python mark is below 50
print("rows with Python below 50:", np.flatnonzero(weak))
print(marks[weak])

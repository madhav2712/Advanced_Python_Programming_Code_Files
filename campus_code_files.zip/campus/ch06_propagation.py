# campus/ch06_propagation.py
def to_number(text):
    print("    to_number: converting", repr(text))
    value = int(text)
    print("    to_number: done")
    return value


def parse_line(line):
    print("  parse_line: start", repr(line))
    roll, text = line.split(",")
    mark = to_number(text)
    print("  parse_line: done")
    return roll, mark


def import_lines(lines):
    for line in lines:
        try:
            print("import_lines: got", parse_line(line))
        except ValueError as error:
            print("import_lines: handled", type(error).__name__, "-", error)


import_lines(["12,81", "07,6O"])
print("main: finished")

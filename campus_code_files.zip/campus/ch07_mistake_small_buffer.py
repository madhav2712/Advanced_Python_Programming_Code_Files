# campus/ch07_mistake_small_buffer.py
import socket

with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as server, \
        socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as client:
    server.bind(("127.0.0.1", 5051))
    client.sendto(b"roll 21 present, lab batch B", ("127.0.0.1", 5051))
    data, address = server.recvfrom(8)
    print("received:", data)

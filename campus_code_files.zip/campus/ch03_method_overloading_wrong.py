# campus/ch03_method_overloading_wrong.py
class Student:
    def __init__(self, marks):
        self.marks = marks

    def total(self):
        return sum(self.marks)

    def total(self, best_of):
        return sum(sorted(self.marks, reverse=True)[:best_of])


meera = Student([84, 91, 47, 76])
print(meera.total(3))
print(meera.total())

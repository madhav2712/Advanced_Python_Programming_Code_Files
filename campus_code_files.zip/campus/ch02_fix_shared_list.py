# campus/ch02_fix_shared_list.py
class Student:
    def __init__(self, name):
        self.name = name
        self.remarks = []          # a fresh list for every student

    def add_remark(self, text):
        self.remarks.append(text)


aisha = Student("Aisha Khan")
rohan = Student("Rohan Patil")
aisha.add_remark("Lab journal submitted")
print(aisha.name, aisha.remarks)
print(rohan.name, rohan.remarks)

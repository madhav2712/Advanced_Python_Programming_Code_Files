# campus/ch03_sequence_example.py
from collections.abc import Sequence


class RollCall(Sequence):
    def __init__(self, names):
        self._names = list(names)

    def __getitem__(self, index):         # required by Sequence
        return self._names[index]

    def __len__(self):                    # required by Sequence
        return len(self._names)


division_a = RollCall(["Aisha Khan", "Rohan Patil", "Meera Iyer", "Farhan Shaikh"])
print(len(division_a), division_a[2])
print("Meera Iyer" in division_a)
print(list(reversed(division_a)))
print(division_a.index("Farhan Shaikh"), division_a.count("Rohan Patil"))
for name in division_a:
    print(" -", name)

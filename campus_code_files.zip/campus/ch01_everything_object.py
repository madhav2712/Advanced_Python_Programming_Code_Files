# campus/ch01_everything_object.py
mark = 78
name = "Aisha Khan"

print(type(mark), type(name), type(len))
print(isinstance(mark, object), isinstance(len, object))
print(name.upper())
print(mark.bit_length())

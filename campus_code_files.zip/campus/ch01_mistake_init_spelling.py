# campus/ch01_mistake_init_spelling.py
class Student:
    def _init_(self, roll, name):
        self.roll = roll
        self.name = name


aisha = Student("12", "Aisha Khan")

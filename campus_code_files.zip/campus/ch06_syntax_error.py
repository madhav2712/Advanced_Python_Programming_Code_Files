# campus/ch06_syntax_error.py
print("checking the Term II marks")
marks = [81, 68, 94]
for mark in marks
    print(mark)

# campus/ch08_widget_tour.py
import tkinter as tk
from tkinter import ttk

root = tk.Tk()
root.title("Lab registration")

tk.Label(root, text="Name").pack(anchor="w", padx=10, pady=(10, 0))
name = tk.Entry(root, width=32)
name.pack(anchor="w", padx=10)

tk.Label(root, text="Subject").pack(anchor="w", padx=10, pady=(8, 0))
subject = ttk.Combobox(root, values=["Python", "Statistics", "Mathematics"],
                       state="readonly", width=29)
subject.current(0)
subject.pack(anchor="w", padx=10)

tk.Label(root, text="Semester").pack(anchor="w", padx=10, pady=(8, 0))
semester = tk.Spinbox(root, from_=1, to=6, width=5)
semester.pack(anchor="w", padx=10)

batch = tk.StringVar(value="A")
for letter in "ABC":
    tk.Radiobutton(root, text=f"Batch {letter}", variable=batch,
                   value=letter).pack(anchor="w", padx=10)

laptop = tk.BooleanVar()
tk.Checkbutton(root, text="I will bring my own laptop",
               variable=laptop).pack(anchor="w", padx=10)

tk.Label(root, text="Remarks").pack(anchor="w", padx=10, pady=(8, 0))
remarks = tk.Text(root, width=32, height=3)
remarks.pack(padx=10)


def register():
    print("name:    ", name.get())
    print("subject: ", subject.get())
    print("semester:", semester.get())
    print("batch:   ", batch.get())
    print("laptop:  ", laptop.get())
    print("remarks: ", remarks.get("1.0", "end").strip())


tk.Button(root, text="Register", command=register).pack(pady=10)
root.mainloop()

# campus/ch09_mistake_nan.py
import pandas as pd
from scipy import stats

df = pd.read_csv("class_marks_gap.csv", dtype={"roll": str})   # one attendance cell is empty
percent = df[["python", "statistics", "lab"]].sum(axis=1) / 250 * 100

print("attendance column:", df["attendance"].dtype, "| empty cells:", df["attendance"].isna().sum())
r = stats.pearsonr(df["attendance"], percent)
print(f"attendance and percentage: r = {r.statistic}, p = {r.pvalue}")

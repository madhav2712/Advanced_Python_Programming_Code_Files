# campus/ch04_deadlock.py
import threading
import time

rank_lock = threading.Lock()
log_lock = threading.Lock()


def update_ranks():
    with rank_lock:
        print("ranker: holding rank_lock, wants log_lock")
        time.sleep(0.1)
        with log_lock:
            print("ranker: done")


def write_log():
    with log_lock:
        print("logger: holding log_lock, wants rank_lock")
        time.sleep(0.1)
        with rank_lock:
            print("logger: done")


ranker = threading.Thread(target=update_ranks, daemon=True)
logger = threading.Thread(target=write_log, daemon=True)
ranker.start()
logger.start()
ranker.join(timeout=2)
logger.join(timeout=2)
print("after 2 s -> ranker alive:", ranker.is_alive(), "| logger alive:", logger.is_alive())

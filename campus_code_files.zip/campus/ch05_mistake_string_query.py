# campus/ch05_mistake_string_query.py
import mysql.connector

connection = mysql.connector.connect(
    host="localhost", user="campus", password="campus123", database="college"
)
cursor = connection.cursor()

roll, name = "34", "Sara D'Souza"

query = f"INSERT INTO students (roll, name) VALUES ('{roll}', '{name}')"
print("query sent:", query)
try:
    cursor.execute(query)
except mysql.connector.Error as error:
    print("refused:", error.errno, error.msg)

cursor.execute("INSERT INTO students (roll, name) VALUES (%s, %s)", (roll, name))
print("with placeholders, rows affected:", cursor.rowcount)
print("statement sent:", cursor.statement)
connection.commit()

cursor.close()
connection.close()

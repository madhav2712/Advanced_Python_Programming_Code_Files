# campus/ch07_mail_server.py
from aiosmtpd.controller import Controller


class CampusMailbox:
    async def handle_RCPT(self, server, session, envelope, address, rcpt_options):
        if not address.endswith("@campus.example"):
            print("server: refused recipient", address)
            return "550 not relaying to that domain"
        envelope.rcpt_tos.append(address)
        return "250 OK"

    async def handle_DATA(self, server, session, envelope):
        print("server: envelope from", envelope.mail_from, "to", envelope.rcpt_tos)
        print(envelope.content.decode("utf-8", errors="replace").rstrip())
        print("server: ---- end of message ----")
        return "250 Message accepted for delivery"


controller = Controller(CampusMailbox(), hostname="127.0.0.1", port=8025,
                        server_hostname="mail.campus.example")
controller.start()
print("server: SMTP on 127.0.0.1 port 8025")
input("server: press Enter to stop\n")
controller.stop()
print("server: stopped")

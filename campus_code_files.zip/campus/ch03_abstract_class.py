# campus/ch03_abstract_class.py
from abc import ABC, abstractmethod


class ReportWriter(ABC):
    def __init__(self, title):
        self.title = title

    @abstractmethod
    def header(self):
        pass

    @abstractmethod
    def row(self, roll, name, total):
        pass

    def write(self, records):                 # concrete: shared by every writer
        lines = [self.header()]
        for roll, name, total in records:
            lines.append(self.row(roll, name, total))
        return "\n".join(lines)


class TextReport(ReportWriter):
    def header(self):
        return f"{self.title}\n{'-' * len(self.title)}"

    def row(self, roll, name, total):
        return f"{roll:>3}  {name:<14}{total:>4}"


class CsvReport(ReportWriter):
    def header(self):
        return "roll,name,total"

    def row(self, roll, name, total):
        return f"{roll},{name},{total}"


records = [("21", "Meera Iyer", 222), ("12", "Aisha Khan", 191)]
print(TextReport("Term I merit list").write(records))
print(CsvReport("unused").write(records))
report = ReportWriter("Term I")

# campus/ch01_encapsulation.py
class Student:
    def __init__(self, roll, name):
        self.roll = roll
        self.name = name
        self._marks = []                # non-public by convention
        self.__portal_pin = "4821"      # name is mangled by Python

    def add_mark(self, mark):
        if 0 <= mark <= 100:
            self._marks.append(mark)
        else:
            print("rejected:", mark)

    def total(self):
        return sum(self._marks)


meera = Student("21", "Meera Iyer")
meera.add_mark(91)
meera.add_mark(140)
print(meera.total())
print(meera._marks)
print(hasattr(meera, "__portal_pin"))
print(meera._Student__portal_pin)

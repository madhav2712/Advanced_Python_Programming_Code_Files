# campus/ch01_del_at_exit.py
class Student:
    def __init__(self, roll):
        self.roll = roll

    def __del__(self):
        print("finalised", self.roll)


rohan = Student("07")
print("last line of the program")

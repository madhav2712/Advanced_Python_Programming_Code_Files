# campus/ch06_logging_exception.py
import logging
from pathlib import Path

logging.basicConfig(filename="campus.log", filemode="w", level=logging.INFO,
                    format="%(levelname)s %(name)s: %(message)s")
log = logging.getLogger("campus.report")


def percent(obtained, maximum):
    return round(obtained / maximum * 100, 1)


for name, obtained, maximum in [("Aisha Khan", 156, 200), ("Farhan Shaikh", 0, 0), ("Meera Iyer", 182, 200)]:
    try:
        print(name, percent(obtained, maximum))
    except ZeroDivisionError:
        log.exception("no percentage for %s", name)
        print(name, "no marks yet")

print("--- campus.log ---")
print(Path("campus.log").read_text(), end="")

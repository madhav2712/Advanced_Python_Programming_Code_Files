# campus/ch01_mistake_no_self.py
class Student:
    def __init__(roll, name):
        roll.name = name


aisha = Student("12", "Aisha Khan")

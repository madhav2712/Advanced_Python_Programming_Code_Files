# campus/ch07_addresses.py
import ipaddress
import socket

docs = socket.gethostbyname("docs.python.org")
print("localhost       ->", socket.gethostbyname("localhost"))
print("docs.python.org ->", docs)

for service in ["ftp", "smtp", "http", "https"]:
    print(f"{service:<6} normally uses TCP port {socket.getservbyname(service, 'tcp')}")
print("domain normally uses UDP port", socket.getservbyname("domain", "udp"))

for text in ["127.0.0.1", "192.168.1.20", docs]:
    address = ipaddress.ip_address(text)
    print(f"{text:<15} loopback: {address.is_loopback!s:<5}  private: {address.is_private}")

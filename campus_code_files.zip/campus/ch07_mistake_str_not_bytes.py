# campus/ch07_mistake_str_not_bytes.py
import socket

left, right = socket.socketpair()
with left, right:
    left.sendall("12,81")
    print(right.recv(1024))

# campus/ch03_method_overriding.py
class Learner:
    def __init__(self, roll, name):
        self.roll = roll
        self.name = name

    def fee(self):
        return 18000

    def __str__(self):                    # overrides object.__str__
        return f"{self.roll} {self.name}"


class ExternalStudent(Learner):
    def fee(self):                        # overrides Learner.fee
        return 9500


class ScholarshipStudent(Learner):
    def fee(self):                        # overrides, and reuses the parent's rule
        return super().fee() // 2


class PlainRecord:
    def __init__(self, roll):
        self.roll = roll


people = [
    Learner("12", "Aisha Khan"),
    ExternalStudent("40", "Kabir Joshi"),
    ScholarshipStudent("21", "Meera Iyer"),
]
for person in people:
    print(f"{str(person):<16} fee {person.fee()}")
print(PlainRecord("15"))

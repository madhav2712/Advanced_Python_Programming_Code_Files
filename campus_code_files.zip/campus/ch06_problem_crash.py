# campus/ch06_problem_crash.py
entries = ["12,81", "07,6O", "21,94", "15,47"]

total = 0
for entry in entries:
    roll, mark = entry.split(",")
    total += int(mark)
    print("added roll", roll, "mark", mark)

print("class average:", total / len(entries))

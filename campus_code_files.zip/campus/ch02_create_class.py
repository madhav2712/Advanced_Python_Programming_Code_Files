# campus/ch02_create_class.py
class SubjectMark:
    """One subject and the marks obtained in it."""

    def __init__(self, subject, obtained, maximum=100):
        self.subject = subject
        self.obtained = obtained
        self.maximum = maximum

    def percent(self):
        return round(self.obtained / self.maximum * 100, 1)


python_mark = SubjectMark("Python", 78)
lab_mark = SubjectMark("Python Lab", 41, 50)

print(type(python_mark).__name__, isinstance(lab_mark, SubjectMark))
print(python_mark.__dict__)
print(lab_mark.subject, lab_mark.percent())
print(python_mark is lab_mark)
print(SubjectMark.__doc__)

# campus/ch05_problem_file.py
from pathlib import Path

register = Path("marks_register.txt")
register.write_text("12,Aisha Khan,78\n07,Rohan Patil,64\n21,Meera Iyer,91\n")

# Rohan's Python mark is corrected from 64 to 68.
# To change one line, the program reads every line and writes every line back.
lines = []
for line in register.read_text().splitlines():
    roll, name, mark = line.split(",")
    if roll == "07":
        mark = "68"
    lines.append(f"{roll},{name},{mark}")
register.write_text("\n".join(lines) + "\n")

# A second line for roll 12 is accepted without any complaint.
with register.open("a") as file:
    file.write("12,Aisha K.,87\n")

print(register.read_text(), end="")
rows_for_12 = [line for line in register.read_text().splitlines() if line.startswith("12,")]
print("lines for roll 12:", len(rows_for_12))

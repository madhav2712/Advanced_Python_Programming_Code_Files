# campus/ch08_mistake_pack_grid.py
import tkinter as tk

root = tk.Tk()
root.title("Mistake 4")
tk.Label(root, text="Roll number").pack(side="left")
tk.Entry(root, width=10).grid(row=0, column=1)
root.mainloop()

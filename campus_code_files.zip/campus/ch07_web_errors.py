# campus/ch07_web_errors.py
from urllib.error import HTTPError, URLError
from urllib.request import urlopen

for url in ["http://127.0.0.1:8000/timetable.html", "http://127.0.0.1:8009/index.html"]:
    try:
        with urlopen(url, timeout=5) as response:
            print(url, "->", response.status)
    except HTTPError as error:
        print(url, "-> HTTP error", error.code, error.reason)
    except URLError as error:
        print(url, "-> could not connect:", error.reason)

# campus/ch01_campus_student.py
class Student:
    def __init__(self, roll, name):
        self.roll = roll
        self.name = name
        self._marks = {}
        print(f"[open]  record {self.roll} for {self.name}")

    def add_mark(self, subject, mark):
        if not 0 <= mark <= 100:
            print(f"[skip]  {subject}: {mark} is outside 0-100")
            return
        self._marks[subject] = mark

    def total(self):
        return sum(self._marks.values())

    def report(self):
        parts = [f"{subject} {mark}" for subject, mark in self._marks.items()]
        return f"{self.roll} {self.name}: {', '.join(parts)} | total {self.total()}"

    def __del__(self):
        print(f"[close] record {self.roll}")


meera = Student("21", "Meera Iyer")
meera.add_mark("Python", 91)
meera.add_mark("Statistics", 84)
meera.add_mark("Networks", 104)
print(meera.report())

meera = Student("07", "Rohan Patil")
print("the name meera now refers to Rohan's record")

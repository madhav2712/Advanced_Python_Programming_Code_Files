# campus/ch01_mistake_init_return.py
class Student:
    def __init__(self, roll, name):
        self.roll = roll
        self.name = name
        return self


aisha = Student("12", "Aisha Khan")

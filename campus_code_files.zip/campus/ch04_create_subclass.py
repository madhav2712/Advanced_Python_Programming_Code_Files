# campus/ch04_create_subclass.py
import threading
import time


class MarkUploader(threading.Thread):
    def __init__(self, subject, rolls):
        super().__init__(name=f"upload-{subject}")
        self.subject = subject
        self.rolls = rolls
        self.uploaded = 0

    def run(self):                        # the work the new thread does
        for roll in self.rolls:
            time.sleep(0.05)
            self.uploaded += 1
        print(f"{self.name}: {self.uploaded} rows uploaded")


uploaders = [
    MarkUploader("python", ["12", "07", "21", "15"]),
    MarkUploader("stats", ["12", "07"]),
]
for u in uploaders:
    u.start()
for u in uploaders:
    u.join()
print("total rows:", sum(u.uploaded for u in uploaders))

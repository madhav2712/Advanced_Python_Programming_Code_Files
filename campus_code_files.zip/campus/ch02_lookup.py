# campus/ch02_lookup.py
class ResultSheet:
    department = "Department of Computer Science"

    def __init__(self, title):
        self.title = title


sheet = ResultSheet("Term I")
print(sheet.__dict__)
print("department" in sheet.__dict__, "department" in ResultSheet.__dict__)
print(sheet.title, "|", sheet.department)
print(sheet.semester)

# campus/ch08_widget_options.py
import tkinter as tk

root = tk.Tk()
label = tk.Label(root, text="Roll 12", fg="navy", font=("Arial", 14))

print("text:", label["text"])
print("fg:  ", label.cget("fg"))
print("font:", label.cget("font"))

label.config(text="Roll 12: Aisha Khan", fg="darkgreen")
label["relief"] = "solid"
print("after the change:", label["text"], "/", label["fg"], "/", label["relief"])

print("a Label has", len(label.keys()), "options; a Button has",
      len(tk.Button(root).keys()))
root.destroy()

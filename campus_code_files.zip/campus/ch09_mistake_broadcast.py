# campus/ch09_mistake_broadcast.py
import numpy as np

marks = np.loadtxt("class_marks.csv", delimiter=",", skiprows=1, usecols=(3, 4, 5), dtype=int)
totals = marks.sum(axis=1)

# Meant: each subject's share of the student's own total.
share = marks / totals * 100
print(share[:3].round(1))

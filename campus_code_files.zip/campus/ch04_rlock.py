# campus/ch04_rlock.py
import threading


class MeritList:
    def __init__(self, lock):
        self.lock = lock
        self.rows = []

    def add(self, roll):
        with self.lock:
            self.rows.append(roll)

    def add_many(self, rolls):
        with self.lock:
            for roll in rolls:
                self.add(roll)            # takes the same lock a second time


safe = MeritList(threading.RLock())
safe.add_many(["21", "12"])
print("with RLock:", safe.rows)

stuck = MeritList(threading.Lock())
worker = threading.Thread(target=stuck.add_many, args=(["21", "12"],), daemon=True)
worker.start()
worker.join(timeout=1)
print("with Lock: still waiting after 1 s?", worker.is_alive(), "| rows:", stuck.rows)

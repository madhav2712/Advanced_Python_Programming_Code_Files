# campus/ch09_ndarray_inside.py
import numpy as np

marks = np.loadtxt("class_marks.csv", delimiter=",", skiprows=1, usecols=(3, 4, 5), dtype=np.int64)
print("dtype:", marks.dtype, "| itemsize:", marks.itemsize, "bytes | nbytes:", marks.nbytes)
print("shape:", marks.shape, "| strides:", marks.strides)

python = marks[:, 0]                     # basic slicing: a view
print("column: shape", python.shape, "| strides", python.strides,
      "| shares memory:", np.shares_memory(python, marks))

turned = marks.T                         # the transpose: a view with the strides swapped
print("transpose: shape", turned.shape, "| strides", turned.strides,
      "| shares memory:", np.shares_memory(turned, marks))

picked = marks[[0, 3]]                   # a list of row numbers: advanced indexing, a copy
copied = marks[:, 0].copy()              # an explicit copy
print("picked rows share memory:", np.shares_memory(picked, marks),
      "| copied column shares memory:", np.shares_memory(copied, marks))

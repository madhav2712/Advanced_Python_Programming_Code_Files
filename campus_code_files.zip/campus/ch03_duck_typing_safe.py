# campus/ch03_duck_typing_safe.py
class GuestAuditor:
    def __init__(self, name):
        self.name = name

    def result(self):
        return "attended, not graded"


class VisitorPass:
    def __init__(self, name):
        self.name = name


def print_result(person):
    if hasattr(person, "result"):
        print(person.name, "->", person.result())
    else:
        print(person.name, "-> no result for this kind of entry")


for entry in [GuestAuditor("Dr. Rao"), VisitorPass("Parent of Rohan")]:
    print_result(entry)

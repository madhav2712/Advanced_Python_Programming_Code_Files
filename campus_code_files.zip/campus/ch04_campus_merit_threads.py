# campus/ch04_campus_merit_threads.py
import threading
import time


class Student:
    def __init__(self, roll, name, marks):
        self.roll = roll
        self.name = name
        self.marks = marks

    def total(self):
        return sum(self.marks)


class MeritList:
    def __init__(self):
        self._rows = []
        self._lock = threading.Lock()

    def add(self, student):
        with self._lock:
            self._rows.append((student.total(), student.roll, student.name))

    def ranked(self):
        with self._lock:
            return sorted(self._rows, reverse=True)


def process_division(division, students, merit):
    for student in students:
        time.sleep(0.2)                   # stands in for fetching marks from a server
        merit.add(student)
    print(f"{division}: {len(students)} students processed")


division_a = [Student("12", "Aisha Khan", [78, 72, 41]),
              Student("07", "Rohan Patil", [64, 70, 35])]
division_b = [Student("21", "Meera Iyer", [91, 84, 47]),
              Student("15", "Farhan Shaikh", [38, 30, 22])]

merit = MeritList()
start = time.perf_counter()
workers = [
    threading.Thread(target=process_division, args=("Division A", division_a, merit)),
    threading.Thread(target=process_division, args=("Division B", division_b, merit)),
]
for w in workers:
    w.start()
for w in workers:
    w.join()
print(f"time: {time.perf_counter() - start:.1f} s")

for rank, (total, roll, name) in enumerate(merit.ranked(), start=1):
    print(rank, roll, name, total)

# campus/ch08_events.py
import tkinter as tk

root = tk.Tk()
root.title("Events")
pad = tk.Label(root, text="click, double-click or move the mouse here",
               bg="#e8eef7", width=40, height=6)
pad.pack(padx=10, pady=10)
entry = tk.Entry(root, width=20)
entry.pack(pady=(0, 10))


def pointer(event):
    print(f"{event.type.name}: the pointer crossed the edge of the label")


def click(event):
    print(f"{event.type.name}: button {event.num} at x={event.x}, y={event.y}")


def double_click(event):
    print(f"double-click at x={event.x}, y={event.y}")


def key(event):
    print(f"{event.type.name}: keysym={event.keysym!r}, char={event.char!r}")


def submit(event):
    print(f"Return pressed; the entry holds {entry.get()!r}")


pad.bind("<Enter>", pointer)
pad.bind("<Leave>", pointer)
pad.bind("<Button-1>", click)
pad.bind("<Double-Button-1>", double_click)
entry.bind("<KeyPress>", key)
entry.bind("<Return>", submit)

root.mainloop()

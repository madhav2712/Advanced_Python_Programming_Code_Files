# campus/ch08_mistake_called_handler.py
import tkinter as tk


def show():
    print("show() ran: looking up roll 12")


root = tk.Tk()
root.title("Mistake 1")
tk.Button(root, text="Show result", command=show()).pack(padx=50, pady=20)
print("window built; waiting for clicks")
root.mainloop()

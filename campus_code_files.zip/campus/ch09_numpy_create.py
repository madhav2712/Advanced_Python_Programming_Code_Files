# campus/ch09_numpy_create.py
import numpy as np

print(np.zeros(4))                       # four zeros, as floats
print(np.ones((2, 3), dtype=int))        # 2 rows and 3 columns of 1
print(np.arange(0, 100, 25))             # like range(): start, stop, step
print(np.linspace(0, 250, 6))            # 6 evenly spaced values; both ends included

seats = np.arange(1, 13).reshape(3, 4)   # 12 seat numbers in 3 rows of 4
print(seats)
print("shape:", seats.shape, "| row 2:", seats[2], "| column 1:", seats[:, 1])

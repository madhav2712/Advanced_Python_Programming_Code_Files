# campus/ch03_overriding.py
class Learner:
    def __init__(self, roll, name):
        self.roll = roll
        self.name = name

    def result(self):
        return f"{self.roll} {self.name}: result pending"

    def id_card(self):
        return f"ID {self.roll} | {self.name}"


class RegularStudent(Learner):
    def __init__(self, roll, name, internal, external):    # overrides the constructor
        super().__init__(roll, name)
        self.internal = internal
        self.external = external

    def result(self):                                      # replaces the parent's method
        total = self.internal + self.external
        return f"{self.roll} {self.name}: {total}/100"

    def id_card(self):                                     # extends the parent's method
        return super().id_card() + " | Regular"


rohan = RegularStudent("07", "Rohan Patil", 18, 49)
print(Learner("99", "New Admission").result())
print(rohan.result())
print(rohan.id_card())

# campus/ch08_class_chain.py
import tkinter as tk

print("tk.Button looks for a method in these classes, in this order:")
for cls in tk.Button.__mro__:
    print("   ", cls.__name__)

print()
for method in ("invoke", "pack", "grid", "place", "bind", "after", "config"):
    owner = next(cls for cls in tk.Button.__mro__ if method in vars(cls))
    print(f"{method + '()':<9} is found in {owner.__name__}")

print("config() is defined in:",
      ", ".join(cls.__name__ for cls in tk.Button.__mro__ if "config" in vars(cls)))

print()
print("tk.Tk:", " -> ".join(cls.__name__ for cls in tk.Tk.__mro__))

# campus/ch04_mistake_args_tuple.py
import threading


def send_notice(name):
    print("sent to", name)


t = threading.Thread(target=send_notice, args=("Meera"))
t.start()
t.join()
print("main thread finished")

# campus/ch07_udp_server.py
import socket

HOST, PORT = "127.0.0.1", 5051

present = []
with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as server:
    server.bind((HOST, PORT))
    print(f"server: waiting for datagrams on {HOST} port {PORT}")
    while True:
        data, address = server.recvfrom(1024)
        text = data.decode("utf-8")
        print(f"server: {len(data)} bytes from {address[0]}: {text}")
        if text == "end":
            break
        present.append(text.split()[1])
        server.sendto(f"noted {text}".encode("utf-8"), address)

print("server: rolls present today:", ", ".join(present))

# campus/ch03_copy_paste_problem.py
class RegularStudent:
    def __init__(self, roll, name, internal, external):
        self.roll = roll
        self.name = name.title()        # bug fix: store names in title case
        self.internal = internal
        self.external = external

    def label(self):
        return f"{self.roll} {self.name}"


class ExternalStudent:
    def __init__(self, roll, name, external):
        self.roll = roll
        self.name = name                # the same fix was never copied here
        self.external = external

    def label(self):
        return f"{self.roll} {self.name}"


print(RegularStudent("12", "aisha khan", 21, 58).label())
print(ExternalStudent("40", "kabir joshi", 61).label())

# campus/ch05_mistake_update_no_where.py
import mysql.connector

connection = mysql.connector.connect(
    host="localhost", user="campus", password="campus123", database="college"
)
cursor = connection.cursor()

# Meant: set Farhan's Statistics mark to 35. The WHERE clause was forgotten.
cursor.execute("UPDATE marks SET obtained = %s", (35,))
print("rows changed:", cursor.rowcount)

cursor.execute("SELECT roll, subject, obtained FROM marks WHERE subject = %s", ("Statistics",))
print("Statistics now:", cursor.fetchall())

connection.rollback()
cursor.execute("SELECT roll, subject, obtained FROM marks WHERE subject = %s", ("Statistics",))
print("after rollback():", cursor.fetchall())

cursor.close()
connection.close()

# campus/ch06_mistake_broad_except.py
def to_mark(text):
    return int(text)


marks = {}
for entry in ["12,81", "07,68", "21,94"]:
    roll, text = entry.split(",")
    try:
        marks[roll] = to_mrak(text)
    except Exception:
        print("roll", roll, "skipped: bad mark", text)

print("marks stored:", marks)

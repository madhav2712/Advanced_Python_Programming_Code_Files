# campus/ch04_logging_threads.py
import logging
import threading

logging.basicConfig(format="%(threadName)-9s %(message)s", level=logging.INFO)


def upload(subject, rows):
    for row in range(1, rows + 1):
        logging.info("%s: row %d uploaded", subject, row)


threads = [
    threading.Thread(target=upload, args=(subject, 3), name=subject)
    for subject in ("python", "stats", "networks")
]
for t in threads:
    t.start()
for t in threads:
    t.join()

# campus/ch04_mistake_start_twice.py
import threading


def send_notice():
    print("notice sent")


t = threading.Thread(target=send_notice)
t.start()
t.join()
t.start()

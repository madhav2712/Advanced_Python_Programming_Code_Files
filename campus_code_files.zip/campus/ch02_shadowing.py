# campus/ch02_shadowing.py
class ResultSheet:
    department = "Department of Computer Science"

    def __init__(self, title):
        self.title = title


term1 = ResultSheet("Term I")
term2 = ResultSheet("Term II")

term1.department = "Department of Physics"
print(term1.department)
print(term2.department)
print(ResultSheet.department)
print(term1.__dict__)

del term1.department
print(term1.department)

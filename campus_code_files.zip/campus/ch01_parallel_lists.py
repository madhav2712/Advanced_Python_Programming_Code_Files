# campus/ch01_parallel_lists.py
rolls = ["12", "07", "21", "15"]
names = ["Aisha Khan", "Rohan Patil", "Meera Iyer", "Farhan Shaikh"]
marks = [78, 64, 91, 55]

names.sort()          # a clerk wanted the notice in alphabetical order

for roll, name, mark in zip(rolls, names, marks):
    print(roll, name, mark)

# campus/ch04_mistake_no_join.py
import threading
import time

results = []


def total_marks(roll, marks):
    time.sleep(0.3)
    results.append((roll, sum(marks)))


for roll, marks in [("12", [78, 72, 41]), ("21", [91, 84, 47])]:
    threading.Thread(target=total_marks, args=(roll, marks)).start()
print("results:", results)

# campus/ch02_mistake_missing_prefix.py
class ResultSheet:
    def __init__(self, title):
        title = title

    def heading(self):
        return self.title.upper()


sheet = ResultSheet("Term I")
print(sheet.heading())

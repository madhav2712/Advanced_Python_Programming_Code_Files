# campus/ch02_variable_types.py
class ResultSheet:
    department = "Department of Computer Science"     # class variable
    sheets_made = 0                                    # class variable

    def __init__(self, title):
        self.title = title                             # instance variable
        ResultSheet.sheets_made += 1

    def header(self):
        rule = "=" * 34                                # local variable
        return f"{rule}\n{self.department}\n{self.title}\n{rule}"


term1 = ResultSheet("Term I Results")
term2 = ResultSheet("Term II Results")

print(term1.header())
print(term1.title, "|", term2.title)
print(term1.department is term2.department)
print("sheets made:", ResultSheet.sheets_made)

ResultSheet.department = "Department of Computer Science and IT"
print(term2.header())

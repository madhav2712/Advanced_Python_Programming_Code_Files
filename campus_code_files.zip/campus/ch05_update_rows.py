# campus/ch05_update_rows.py
import mysql.connector

connection = mysql.connector.connect(
    host="localhost", user="campus", password="campus123", database="college"
)
cursor = connection.cursor()

show = "SELECT obtained FROM marks WHERE roll = %s AND subject = %s"

# Meera's practical paper was re-checked: 47 becomes 49.
cursor.execute(show, ("21", "Python Lab"))
print("before:", cursor.fetchone()[0])
cursor.execute(
    "UPDATE marks SET obtained = %s WHERE roll = %s AND subject = %s",
    (49, "21", "Python Lab"),
)
print("rows changed:", cursor.rowcount)
cursor.execute(show, ("21", "Python Lab"))
print("after:", cursor.fetchone()[0])

# A roll number that does not exist changes nothing, and raises no error.
cursor.execute("UPDATE students SET division = %s WHERE roll = %s", ("B", "99"))
print("rows changed for roll 99:", cursor.rowcount)

# One statement can change many rows: 2 grace marks for each Statistics mark below 35.
cursor.execute(
    "UPDATE marks SET obtained = obtained + 2 WHERE subject = %s AND obtained < %s",
    ("Statistics", 35),
)
print("grace marks given:", cursor.rowcount)

connection.commit()
cursor.close()
connection.close()

# campus/ch07_download.py
from pathlib import Path
from urllib.request import urlopen


def download(url, filename):
    with urlopen(url, timeout=5) as response:
        kind = response.headers["Content-Type"]
        data = response.read()
    Path(filename).write_bytes(data)
    print(f"saved {filename}: {len(data)} bytes of {kind}")
    return data


download("http://127.0.0.1:8000/index.html", "notice_copy.html")
image = download("http://127.0.0.1:8000/logo.gif", "logo_copy.gif")
print("the image starts with", image[:6])

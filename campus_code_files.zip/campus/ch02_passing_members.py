# campus/ch02_passing_members.py
class SubjectMark:
    def __init__(self, subject, obtained):
        self.subject = subject
        self.obtained = obtained


class Student:
    def __init__(self, roll, name):
        self.roll = roll
        self.name = name
        self.marks = []

    def attach(self, mark):
        self.marks.append(mark)


class Moderation:
    @staticmethod
    def add_grace(mark, extra):
        if mark.obtained < 40 <= mark.obtained + extra:
            mark.obtained += extra


class ResultSheet:
    def __init__(self, title):
        self.title = title
        self.rows = []

    def add(self, student):
        self.rows.append(student)

    def show(self):
        print(self.title)
        for student in self.rows:
            parts = [f"{m.subject} {m.obtained}" for m in student.marks]
            print(" ", student.roll, student.name, "-", ", ".join(parts))


rohan = Student("07", "Rohan Patil")
networks = SubjectMark("Networks", 37)
rohan.attach(SubjectMark("Python", 64))
rohan.attach(networks)

Moderation.add_grace(networks, 3)       # a member of rohan goes to another class

sheet = ResultSheet("Term I")
sheet.add(rohan)                        # the whole object goes to another class
sheet.show()
print(networks is rohan.marks[1])

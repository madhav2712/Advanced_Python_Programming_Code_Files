# campus/ch07_tcp_server.py
import socket

HOST, PORT = "127.0.0.1", 5050

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
    server.bind((HOST, PORT))
    server.listen()
    print(f"server: listening on {HOST} port {PORT}")

    connection, address = server.accept()
    with connection:
        print("server: connection from", address)
        data = connection.recv(1024)
        print(f"server: received {len(data)} bytes: {data.decode('utf-8')}")
        reply = f"exam cell received {len(data)} bytes"
        connection.sendall(reply.encode("utf-8"))

print("server: closed")

# campus/ch03_mistake_diamond_twice.py
class Person:
    def __init__(self, name):
        print("Person.__init__ for", name)
        self.name = name


class Learner(Person):
    def __init__(self, name, roll):
        Person.__init__(self, name)
        self.roll = roll


class Employee(Person):
    def __init__(self, name, staff_id):
        Person.__init__(self, name)
        self.staff_id = staff_id


class LabAssistant(Learner, Employee):
    def __init__(self, name, roll, staff_id):
        Learner.__init__(self, name, roll)
        Employee.__init__(self, name, staff_id)


meera = LabAssistant("Meera Iyer", "21", "LA-03")

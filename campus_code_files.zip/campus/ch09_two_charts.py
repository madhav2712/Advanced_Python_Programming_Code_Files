# campus/ch09_two_charts.py
import matplotlib.pyplot as plt
import numpy as np

data = np.loadtxt("class_marks.csv", delimiter=",", skiprows=1, usecols=(3, 4, 5, 6), dtype=int)
percent = data[:, :3].sum(axis=1) / 250 * 100
attendance = data[:, 3]

fig, (left, right) = plt.subplots(1, 2, figsize=(9, 3.5), layout="constrained")   # two Axes

counts, edges, bars = left.hist(percent, bins=[30, 40, 50, 60, 70, 80, 90], edgecolor="black")
left.set_title("Students in each band")
left.set_xlabel("Percentage")
left.set_ylabel("Number of students")
left.set_yticks(range(5))

right.scatter(attendance, percent)
right.set_title("Attendance and result")
right.set_xlabel("Attendance (%)")
right.set_ylabel("Percentage")

fig.savefig("chart_class.png", dpi=150)
print("Axes in the figure:", len(fig.axes))
print("bands:", edges.tolist())
print("students in each band:", counts.tolist())

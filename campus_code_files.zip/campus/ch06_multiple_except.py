# campus/ch06_multiple_except.py
maximum = {"Python": 100, "Python Lab": 50, "Seminar": 0}


def percent(subject, text):
    return round(int(text) / maximum[subject] * 100, 1)


tests = [("Python", "81"), ("Python", "eighty"), ("Physics", "70"),
         ("Seminar", "10"), ("Python Lab", None), ("Python Lab", "41")]

for subject, text in tests:
    try:
        print(subject, text, "->", percent(subject, text), "%")
    except ValueError as error:
        print(subject, text, "-> not a whole number:", error)
    except KeyError as error:
        print(subject, text, "-> unknown subject:", error)
    except (ZeroDivisionError, TypeError) as error:
        print(subject, text, "->", type(error).__name__ + ":", error)

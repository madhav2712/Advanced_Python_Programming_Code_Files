# campus/ch02_campus_result_sheet.py
class SubjectMark:
    def __init__(self, subject, obtained, maximum=100):
        self.subject = subject
        self.obtained = obtained
        self.maximum = maximum


class Student:
    def __init__(self, roll, name):
        self.roll = roll
        self.name = name
        self.marks = []

    @classmethod
    def from_record(cls, record):
        roll, name = record.split(",")
        return cls(roll.strip(), name.strip())

    def attach(self, mark):
        self.marks.append(mark)

    def total(self):
        return sum(m.obtained for m in self.marks)

    def maximum(self):
        return sum(m.maximum for m in self.marks)


class ResultSheet:
    department = "Department of Computer Science"
    pass_percent = 40

    def __init__(self, title):
        self.title = title
        self.students = []

    def add(self, student):
        self.students.append(student)

    @classmethod
    def grade(cls, percent):
        if percent >= 75:
            return "Distinction"
        if percent >= 60:
            return "First Class"
        if percent >= cls.pass_percent:
            return "Pass"
        return "Fail"

    @staticmethod
    def percent(obtained, maximum):
        return round(obtained / maximum * 100, 1)

    def print_sheet(self):
        print(self.department)
        print(self.title)
        print(f"{'Roll':<6}{'Name':<16}{'Total':>6}{'%':>7}  Grade")
        for s in self.students:
            p = self.percent(s.total(), s.maximum())
            print(f"{s.roll:<6}{s.name:<16}{s.total():>6}{p:>7}  {self.grade(p)}")


records = ["12, Aisha Khan", "07, Rohan Patil", "21, Meera Iyer", "15, Farhan Shaikh"]
scores = {
    "12": (78, 72, 41),
    "07": (64, 70, 35),
    "21": (91, 84, 47),
    "15": (38, 30, 22),
}

sheet = ResultSheet("Term I Result Sheet")
for record in records:
    student = Student.from_record(record)
    python, stats, lab = scores[student.roll]
    student.attach(SubjectMark("Python", python))
    student.attach(SubjectMark("Statistics", stats))
    student.attach(SubjectMark("Python Lab", lab, 50))
    sheet.add(student)

sheet.print_sheet()

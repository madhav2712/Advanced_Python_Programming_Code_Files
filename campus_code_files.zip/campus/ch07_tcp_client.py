# campus/ch07_tcp_client.py
import socket

SERVER = ("127.0.0.1", 5050)

with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client:
    client.connect(SERVER)
    print("client: my end is", client.getsockname())
    print("client: other end is", client.getpeername())
    message = "Term II Python marks: 12,81 07,60 21,94"
    client.sendall(message.encode("utf-8"))
    reply = client.recv(1024).decode("utf-8")
    print("client: reply:", reply)

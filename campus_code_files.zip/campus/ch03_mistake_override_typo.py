# campus/ch03_mistake_override_typo.py
class Learner:
    def fee(self):
        return 18000


class ExternalStudent(Learner):
    def fees(self):                       # meant to override fee()
        return 9500


print(ExternalStudent().fee())

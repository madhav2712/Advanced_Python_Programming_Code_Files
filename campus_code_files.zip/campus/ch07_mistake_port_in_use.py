# campus/ch07_mistake_port_in_use.py
import socket

first = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
first.bind(("127.0.0.1", 5050))
first.listen()
print("first server: listening on port 5050")

second = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
second.bind(("127.0.0.1", 5050))
print("second server: listening on port 5050")

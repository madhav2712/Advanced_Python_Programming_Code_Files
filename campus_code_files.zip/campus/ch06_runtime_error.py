# campus/ch06_runtime_error.py
def percent(obtained, maximum):
    return round(obtained / maximum * 100, 1)


def report(name, obtained, maximum):
    print(name, percent(obtained, maximum), "%")


print("checking the Term II marks")
report("Aisha Khan", 156, 200)
report("Farhan Shaikh", 0, 0)
report("Meera Iyer", 182, 200)

# campus/ch07_mistake_one_recv.py
import socket
import time

client, server = socket.socketpair()
with client, server:
    client.sendall(b"12,81")
    client.sendall(b"07,60")
    client.sendall(b"21,94")
    time.sleep(0.5)

    first = server.recv(1024)
    print("first recv() returned:", first)
    roll, mark = first.decode("utf-8").split(",")
    print("roll", roll, "mark", int(mark))

# campus/ch07_result_server.py
import socketserver
import threading

HOST, PORT = "127.0.0.1", 5052
MAXIMUM = 250
TOTALS = {
    "07": ("Rohan Patil", 173),
    "12": ("Aisha Khan", 191),
    "15": ("Farhan Shaikh", 92),
    "21": ("Meera Iyer", 224),
}


def grade(percent):
    if percent >= 75:
        return "Distinction"
    if percent >= 60:
        return "First Class"
    if percent >= 40:
        return "Pass"
    return "Fail"


def answer(request):
    command, _, roll = request.partition(" ")
    if command == "BYE":
        return "OK bye"
    if command != "RESULT":
        return f"ERR unknown command {command}"
    if roll not in TOTALS:
        return f"ERR no student has roll {roll}"
    name, total = TOTALS[roll]
    percent = round(total / MAXIMUM * 100, 1)
    return f"OK {roll} {name} {total} {percent} {grade(percent)}"


class ResultHandler(socketserver.StreamRequestHandler):
    def handle(self):
        print("server: a client connected")
        for line in self.rfile:
            request = line.decode("utf-8").strip()
            reply = answer(request)
            self.wfile.write((reply + "\n").encode("utf-8"))
            print(f"server: {request!r} -> {reply!r}")
            if request == "BYE":
                break
        print("server: the client left")


server = socketserver.ThreadingTCPServer((HOST, PORT), ResultHandler)
threading.Thread(target=server.serve_forever, daemon=True).start()
print(f"server: results service on {HOST} port {PORT}")
input("server: press Enter to stop\n")
server.shutdown()
server.server_close()
print("server: stopped")

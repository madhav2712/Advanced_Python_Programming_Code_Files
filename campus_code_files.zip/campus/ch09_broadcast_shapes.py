# campus/ch09_broadcast_shapes.py
import numpy as np

print("(12, 3) with (3,)   ->", np.broadcast_shapes((12, 3), (3,)))      # one value per subject
print("(12, 3) with (12, 1) ->", np.broadcast_shapes((12, 3), (12, 1)))  # one value per student
print("(12, 1) with (1, 3)  ->", np.broadcast_shapes((12, 1), (1, 3)))   # a column and a row
try:
    np.broadcast_shapes((12, 3), (12,))
except ValueError as error:
    print("(12, 3) with (12,)  -> ValueError:", error)

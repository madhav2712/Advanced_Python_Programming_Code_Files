# campus/ch08_mistake_no_event.py
import tkinter as tk

root = tk.Tk()
root.title("Mistake 3")
roll = tk.Entry(root, width=10)
roll.pack(side="left", padx=10, pady=10)


def show():
    print("result requested for roll", roll.get())


tk.Button(root, text="Show", command=show).pack(side="left", padx=10)
roll.bind("<Return>", show)
root.mainloop()

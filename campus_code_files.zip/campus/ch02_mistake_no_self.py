# campus/ch02_mistake_no_self.py
class ResultSheet:
    def __init__(self, title):
        self.title = title
        self.rows = []

    def add(student):
        self.rows.append(student)


sheet = ResultSheet("Term I")
sheet.add("Aisha Khan")

# campus/ch09_read_csv.py
import pandas as pd

df = pd.read_csv("class_marks.csv", dtype={"roll": str})   # keep "03" as text, not the number 3
print(df.head())
print("shape:", df.shape)
print(df.dtypes)
print(df[["python", "statistics", "lab"]].describe().round(1))

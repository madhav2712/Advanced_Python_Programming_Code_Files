# campus/ch06_campus_import.py
import logging
from pathlib import Path

logging.basicConfig(
    filename="campus.log",
    filemode="w",
    level=logging.INFO,
    format="%(asctime)s %(levelname)-8s %(name)s: %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger("campus.import")

MAXIMUM = {"Python": 100, "Statistics": 100, "Python Lab": 50}


class CampusError(Exception):
    """Base class for every error that the Campus Toolkit raises."""


class BadLineError(CampusError):
    def __init__(self, line, reason):
        super().__init__(f"{reason}: {line!r}")
        self.line = line


class UnknownStudentError(CampusError):
    def __init__(self, roll):
        super().__init__(f"no student has roll {roll}")
        self.roll = roll


class InvalidMarkError(CampusError):
    def __init__(self, roll, subject, obtained, maximum):
        super().__init__(f"roll {roll}: {obtained} is outside 0 to {maximum} in {subject}")
        self.roll = roll
        self.obtained = obtained
        self.maximum = maximum


class SubjectMark:
    def __init__(self, subject, obtained, maximum=100):
        self.subject = subject
        self.obtained = obtained
        self.maximum = maximum


class Student:
    def __init__(self, roll, name):
        self.roll = roll
        self.name = name
        self.marks = []

    def attach(self, mark):
        self.marks.append(mark)

    def percent(self):
        obtained = sum(m.obtained for m in self.marks)
        maximum = sum(m.maximum for m in self.marks)
        return round(obtained / maximum * 100, 1)


class MarksImporter:
    def __init__(self, students):
        self.students = {s.roll: s for s in students}

    def parse(self, line):
        parts = [part.strip() for part in line.split(",")]
        if len(parts) != 3:
            raise BadLineError(line, "expected roll,subject,mark")
        roll, subject, text = parts
        if subject not in MAXIMUM:
            raise BadLineError(line, "unknown subject")
        obtained = int(text)
        if roll not in self.students:
            raise UnknownStudentError(roll)
        if not 0 <= obtained <= MAXIMUM[subject]:
            raise InvalidMarkError(roll, subject, obtained, MAXIMUM[subject])
        return roll, SubjectMark(subject, obtained, MAXIMUM[subject])

    def load(self, filename):
        accepted = rejected = 0
        with open(filename, encoding="utf-8") as file:
            for number, line in enumerate(file, start=1):
                try:
                    roll, mark = self.parse(line.strip())
                except ValueError as error:
                    log.warning("%s line %d skipped: the mark is not a whole number (%s)",
                                filename, number, error)
                    rejected += 1
                except CampusError as error:
                    log.warning("%s line %d skipped: %s", filename, number, error)
                    rejected += 1
                else:
                    self.students[roll].attach(mark)
                    accepted += 1
        log.info("%s: %d lines accepted, %d rejected", filename, accepted, rejected)
        return accepted, rejected


Path("term2_marks.txt").write_text(
    "12,Python,81\n07,Python,6O\n21,Python,94\n15,Python,105\n"
    "33,Python,55\n12,Statistics,75\n07,Statistics,68\n21,Statistics\n"
)

importer = MarksImporter([Student("07", "Rohan Patil"), Student("12", "Aisha Khan"),
                          Student("15", "Farhan Shaikh"), Student("21", "Meera Iyer")])

for filename in ["term2_marks.txt", "term2_lab.txt"]:
    try:
        accepted, rejected = importer.load(filename)
    except FileNotFoundError as error:
        log.error("cannot open %s: %s", filename, error.strerror)
        print(f"{filename}: not found, nothing imported")
    else:
        print(f"{filename}: {accepted} accepted, {rejected} rejected (see campus.log)")

for student in importer.students.values():
    try:
        print(f"{student.roll}  {student.name:<15}{student.percent():>6} %")
    except ZeroDivisionError:
        log.exception("no percentage for roll %s", student.roll)
        print(f"{student.roll}  {student.name:<15}  no marks yet")

print("--- campus.log ---")
print(Path("campus.log").read_text(), end="")

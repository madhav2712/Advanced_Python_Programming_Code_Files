# campus/ch03_polymorphism.py
class Learner:
    def __init__(self, roll, name):
        self.roll = roll
        self.name = name

    def result(self):
        return "pending"


class RegularStudent(Learner):
    def __init__(self, roll, name, internal, external):
        super().__init__(roll, name)
        self.internal = internal
        self.external = external

    def result(self):
        return f"{self.internal + self.external}/100"


class ExternalStudent(Learner):
    def __init__(self, roll, name, external):
        super().__init__(roll, name)
        self.external = external

    def result(self):
        return f"{self.external}/75 (external only)"


def print_result(learner):
    print(f"{learner.roll:>3} {learner.name:<14} {learner.result()}")


batch = [
    RegularStudent("12", "Aisha Khan", 21, 58),
    ExternalStudent("40", "Kabir Joshi", 61),
    Learner("99", "New Admission"),
]
for learner in batch:
    print_result(learner)

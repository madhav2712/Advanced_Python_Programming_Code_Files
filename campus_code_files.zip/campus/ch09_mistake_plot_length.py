# campus/ch09_mistake_plot_length.py
import matplotlib.pyplot as plt

names = ["Rohan", "Aisha", "Farhan", "Meera"]
totals = [173, 191, 224]                 # Farhan's total was left out by mistake

fig, ax = plt.subplots()
ax.plot(names, totals, marker="o")
fig.savefig("chart_wrong.png")

# campus/ch03_mistake_sum_without_radd.py
class Score:
    def __init__(self, obtained, maximum):
        self.obtained = obtained
        self.maximum = maximum

    def __add__(self, other):
        return Score(self.obtained + other.obtained, self.maximum + other.maximum)


print(sum([Score(30, 40), Score(25, 35)]))

# campus/ch08_close_window.py
import tkinter as tk
from tkinter import messagebox

root = tk.Tk()
root.title("Marks entry")
saved = tk.BooleanVar(value=False)

tk.Label(root, text="Python mark of roll 12").pack(padx=70, pady=(15, 5))
mark = tk.Entry(root, width=10)
mark.pack()


def save():
    saved.set(True)
    print("mark saved:", mark.get())


def on_close():
    if not saved.get():
        if not messagebox.askyesno("Close the window?",
                                   "The mark is not saved. Close anyway?"):
            print("close cancelled")
            return
    print("window closed")
    root.destroy()


tk.Button(root, text="Save", command=save).pack(pady=15)
root.protocol("WM_DELETE_WINDOW", on_close)
root.mainloop()

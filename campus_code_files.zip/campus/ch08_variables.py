# campus/ch08_variables.py
import tkinter as tk

TOTALS = {"07": 173, "12": 191, "15": 92, "21": 224}

root = tk.Tk()
root.title("Live lookup")
roll = tk.StringVar()
answer = tk.StringVar(value="type a roll number")


def update(*args):
    total = TOTALS.get(roll.get())
    if total is None:
        answer.set("no student with that roll number")
    else:
        answer.set(f"total {total} out of 250")
    print(f"roll is now {roll.get()!r}: {answer.get()}")


roll.trace_add("write", update)
tk.Entry(root, textvariable=roll, width=10).pack(padx=20, pady=(15, 5))
tk.Label(root, textvariable=answer, width=30).pack(padx=20, pady=(0, 15))
root.mainloop()

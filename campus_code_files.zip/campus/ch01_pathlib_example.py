# campus/ch01_pathlib_example.py
import os.path
from pathlib import Path

old = os.path.join("reports", "2026", "marks.csv")
print(old, os.path.splitext(os.path.basename(old))[1])

report = Path("reports") / "2026" / "marks.csv"
print(report, report.suffix, report.stem, report.parent)

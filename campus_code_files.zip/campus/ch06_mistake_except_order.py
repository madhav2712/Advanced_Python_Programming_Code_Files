# campus/ch06_mistake_except_order.py
maximum = {"Python": 100, "Python Lab": 50}

for subject, text in [("Python", "6O"), ("Physics", "70")]:
    try:
        print(subject, int(text) / maximum[subject])
    except Exception as error:
        print(subject, "- something went wrong:", error)
    except ValueError:
        print(subject, "- the mark must be a whole number")
    except KeyError:
        print(subject, "- there is no such subject")

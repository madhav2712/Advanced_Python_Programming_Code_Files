# campus/ch04_create_function.py
import threading
import time


def send_notice(name, delay):
    me = threading.current_thread().name
    print(f"{me}: preparing notice for {name}")
    time.sleep(delay)
    print(f"{me}: sent to {name}")


t1 = threading.Thread(target=send_notice, args=("Aisha Khan", 0.4), name="mailer-1")
t2 = threading.Thread(target=send_notice, args=("Rohan Patil", 0.2), name="mailer-2")

t1.start()
time.sleep(0.05)
t2.start()
time.sleep(0.05)
print(f"{threading.current_thread().name}: both threads started")

t1.join()
t2.join()
print(f"{threading.current_thread().name}: all notices sent")

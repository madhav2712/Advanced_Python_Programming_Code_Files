# campus/ch01_features.py
class Student:
    def __init__(self, name, marks):
        self.name = name
        self.marks = marks

    def average(self):
        return round(sum(self.marks) / len(self.marks), 2)


class RegularStudent(Student):
    pass


farhan = RegularStudent("Farhan Shaikh", [55, 61, 48])
print(farhan.name, farhan.average())

print(len("Farhan"), len([55, 61, 48]), len({"15": 55}))
print(3 + 4, "Py" + "thon", [55] + [61])

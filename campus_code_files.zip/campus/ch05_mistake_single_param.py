# campus/ch05_mistake_single_param.py
import mysql.connector

connection = mysql.connector.connect(
    host="localhost", user="campus", password="campus123", database="college"
)
cursor = connection.cursor()

cursor.execute("SELECT name FROM students WHERE roll = %s", ("12"))
print(cursor.fetchone())

cursor.close()
connection.close()

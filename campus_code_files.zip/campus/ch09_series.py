# campus/ch09_series.py
import pandas as pd

totals = pd.Series([173, 191, 92, 224], index=["07", "12", "15", "21"], name="total")
print(totals)
print("by label '12':", totals["12"], "| by position 0:", totals.iloc[0])
print("values:", totals.to_numpy(), "of type", type(totals.to_numpy()).__name__)
print(totals[totals >= 150])
print("mean:", totals.mean())

bonus = pd.Series({"21": 3, "12": 5})    # a different order, and only two students
print(totals + bonus)                    # matched by label, not by position
print(totals.add(bonus, fill_value=0))

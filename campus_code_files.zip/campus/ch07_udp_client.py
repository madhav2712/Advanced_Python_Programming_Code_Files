# campus/ch07_udp_client.py
import socket

SERVER = ("127.0.0.1", 5051)

with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as client:
    client.settimeout(2)
    for roll in ["07", "12", "21"]:
        sent = client.sendto(f"roll {roll} present".encode("utf-8"), SERVER)
        reply, address = client.recvfrom(1024)
        print(f"client: sent {sent} bytes, reply: {reply.decode('utf-8')}")
    client.sendto(b"end", SERVER)
    print("client: sent end")

# campus/ch05_dbapi_globals.py
import sqlite3

import mysql.connector

print("mysql.connector apilevel  :", mysql.connector.apilevel)
print("mysql.connector paramstyle:", mysql.connector.paramstyle)
print("mysql.connector threadsafety:", mysql.connector.threadsafety)
print("sqlite3 apilevel  :", sqlite3.apilevel)
print("sqlite3 paramstyle:", sqlite3.paramstyle)

connection = mysql.connector.connect(
    host="localhost", user="campus", password="campus123", database="college"
)
cursor = connection.cursor()
names = ["cursor", "commit", "rollback", "close"]
print("connection has:", [name for name in names if hasattr(connection, name)])
names = ["execute", "executemany", "fetchone", "fetchmany", "fetchall", "rowcount", "description"]
print("cursor has:", [name for name in names if hasattr(cursor, name)])

cursor.execute("SELECT roll, name FROM students WHERE roll = %s", ("21",))
cursor.fetchall()
print("description:", [column[0] for column in cursor.description])

cursor.close()
connection.close()

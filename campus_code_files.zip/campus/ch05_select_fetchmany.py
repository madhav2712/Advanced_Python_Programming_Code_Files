# campus/ch05_select_fetchmany.py
import mysql.connector

connection = mysql.connector.connect(
    host="localhost", user="campus", password="campus123", database="college"
)

cursor = connection.cursor()
cursor.execute(
    "SELECT roll, obtained FROM marks WHERE subject = %s ORDER BY obtained DESC",
    ("Python",),
)
print("top two in Python:", cursor.fetchmany(2))
print("the rest:", cursor.fetchall())
cursor.close()

cursor = connection.cursor(dictionary=True)
cursor.execute("SELECT subject, obtained, maximum FROM marks WHERE roll = %s", ("12",))
for row in cursor:
    print(row["subject"], "->", row["obtained"], "out of", row["maximum"])
cursor.close()

connection.close()

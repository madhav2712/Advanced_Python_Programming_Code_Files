# campus/ch08_first_window.py
import tkinter as tk

root = tk.Tk()
root.title("Campus Toolkit")
root.geometry("360x140")

greeting = tk.Label(root, text="Welcome to the exam cell result desk")
greeting.pack(pady=25)

close = tk.Button(root, text="Close", command=root.destroy)
close.pack()

print("window built; starting the event loop")
root.mainloop()
print("event loop ended: the window was closed")

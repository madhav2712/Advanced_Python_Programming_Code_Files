# campus/ch02_method_types.py
class Student:
    pass_mark = 40

    def __init__(self, roll, name):
        self.roll = roll
        self.name = name
        self.marks = {}

    def set_mark(self, subject, mark):          # instance method (mutator)
        if Student.is_valid(mark):
            self.marks[subject] = mark

    def get_total(self):                         # instance method (accessor)
        return sum(self.marks.values())

    @classmethod
    def from_record(cls, record):                # class method: another way to build
        roll, name = record.split(",")
        return cls(roll.strip(), name.strip())

    @classmethod
    def change_pass_mark(cls, new_mark):         # class method: changes shared data
        cls.pass_mark = new_mark

    @staticmethod
    def is_valid(mark):                          # static method: needs no object
        return 0 <= mark <= 100


farhan = Student.from_record("15, Farhan Shaikh")
farhan.set_mark("Python", 38)
farhan.set_mark("Networks", 120)
print(farhan.roll, farhan.name, farhan.marks, farhan.get_total())

print(Student.is_valid(55), Student.is_valid(-3))
print("pass mark:", Student.pass_mark)
Student.change_pass_mark(35)
print("pass mark seen by farhan:", farhan.pass_mark)

# campus/ch02_mistake_static_self.py
class SubjectMark:
    def __init__(self, obtained):
        self.obtained = obtained

    @staticmethod
    def is_pass():
        return self.obtained >= 40


print(SubjectMark(55).is_pass())

# campus/ch08_mistake_grid_none.py
import tkinter as tk

root = tk.Tk()
root.title("Mistake 2")
roll = tk.Entry(root, width=10).grid(row=0, column=0, padx=10, pady=10)


def show():
    print("roll typed:", roll.get())


tk.Button(root, text="Show", command=show).grid(row=0, column=1, padx=10)
root.mainloop()

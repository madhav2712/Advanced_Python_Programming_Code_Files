# campus/ch06_mistake_error_not_exception.py
import logging
from pathlib import Path

logging.basicConfig(filename="campus.log", filemode="w", format="%(levelname)s %(message)s")


def to_mark(text):
    return int(text)


def import_line(line):
    roll, text = line.split(",")
    return roll, to_mark(text)


for line in ["12,81", "07,6O"]:
    try:
        import_line(line)
    except ValueError as error:
        logging.error(error)

print(Path("campus.log").read_text(), end="")

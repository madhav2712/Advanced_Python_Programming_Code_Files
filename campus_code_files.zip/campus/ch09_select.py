# campus/ch09_select.py
import numpy as np
import pandas as pd

df = pd.read_csv("class_marks.csv", dtype={"roll": str}).set_index("roll")
print(df["name"].head(3))                          # one column: a Series
print(df.loc["12", ["name", "python"]].to_dict())  # one row and two columns, by label
print(df.iloc[0, 0])                               # first row, first column, by position

df["total"] = df["python"] + df["statistics"] + df["lab"]
df["percent"] = (df["total"] / 250 * 100).round(1)
df["grade"] = np.select([df["percent"] >= 75, df["percent"] >= 60, df["percent"] >= 40],
                        ["Distinction", "First Class", "Pass"], default="Fail")

top = df[df["percent"] >= 75].sort_values("percent", ascending=False)
print(top[["name", "division", "percent", "grade"]])

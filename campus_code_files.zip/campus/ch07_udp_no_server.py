# campus/ch07_udp_no_server.py
import socket

NOBODY = ("127.0.0.1", 5059)

with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as client:
    client.settimeout(2)
    sent = client.sendto(b"roll 15 present", NOBODY)
    print(f"client: sendto() reports {sent} bytes sent")
    try:
        reply, address = client.recvfrom(1024)
        print("client: reply:", reply)
    except TimeoutError:
        print("client: no reply within 2 seconds")
    except ConnectionResetError as error:
        print("client: an error came back instead of a reply:", error)

# campus/ch07_ftp_client.py
from ftplib import FTP, error_perm
from pathlib import Path

Path("term2_marks.csv").write_text(
    "roll,subject,mark\n12,Python,81\n07,Python,60\n21,Python,94\n", encoding="utf-8")

with FTP() as ftp:
    ftp.connect("127.0.0.1", 2121)
    print("welcome:", ftp.getwelcome())
    ftp.set_debuglevel(1)
    ftp.login("campus", "campus123")
    with open("timetable_copy.txt", "wb") as file:
        ftp.retrbinary("RETR timetable.txt", file.write)
    ftp.set_debuglevel(0)

    with open("term2_marks.csv", "rb") as file:
        print("upload:", ftp.storbinary("STOR term2_marks.csv", file))
    print("files on the server:", ftp.nlst())

print("downloaded copy:")
print(Path("timetable_copy.txt").read_text(encoding="utf-8"), end="")

with FTP() as ftp:
    ftp.connect("127.0.0.1", 2121)
    try:
        ftp.login("campus", "campus12")
    except error_perm as error:
        print("second session, login refused:", error)

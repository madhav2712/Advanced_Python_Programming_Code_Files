# campus/ch04_lock_fix.py
import threading
import time


class LabSlots:
    def __init__(self, seats):
        self.seats = seats
        self.booked = []
        self.waiting = []
        self.lock = threading.Lock()

    def book(self, name):
        with self.lock:                   # only one thread at a time in here
            if self.seats == 0:
                self.waiting.append(name)
                return
            time.sleep(0.01)
            self.seats -= 1
            self.booked.append(name)


lab = LabSlots(seats=2)
names = ["Aisha", "Rohan", "Meera", "Farhan", "Kabir"]
threads = [threading.Thread(target=lab.book, args=(n,)) for n in names]
for t in threads:
    t.start()
for t in threads:
    t.join()
print("booked:", lab.booked)
print("waiting:", lab.waiting)
print("seats left:", lab.seats)

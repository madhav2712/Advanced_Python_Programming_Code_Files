# campus/ch08_widget_tree.py
import tkinter as tk

from ch08_result_desk import ResultDesk


def show(widget, depth=0):
    manager = widget.winfo_manager() or "-"
    print(f"{'    ' * depth + str(widget):<34} {widget.winfo_class():<9} {manager}")
    for child in widget.winfo_children():
        show(child, depth + 1)


root = tk.Tk()
desk = ResultDesk(root)
desk.pack(fill="both", expand=True)
desk.status.pack(fill="x")
print(f"{'path name':<34} {'class':<9} geometry manager")
show(root)
print("the Entry's Python object is", type(desk.roll), "named", repr(str(desk.roll)))
button = desk.grid_slaves(row=1, column=2)[0]
print("the button's command option holds the Tcl command", repr(button.cget("command")))
root.destroy()

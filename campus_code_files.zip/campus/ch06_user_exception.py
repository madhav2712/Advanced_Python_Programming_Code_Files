# campus/ch06_user_exception.py
class InvalidMarkError(Exception):
    pass


def check_mark(obtained, maximum):
    if not 0 <= obtained <= maximum:
        raise InvalidMarkError(f"mark {obtained} is outside 0 to {maximum}")
    return obtained


try:
    check_mark(105, 100)
except InvalidMarkError as error:
    print("caught:", type(error).__name__, "-", error)

print("the class and its parents:", [c.__name__ for c in InvalidMarkError.__mro__])

check_mark(-4, 100)

# campus/ch03_abstract_method.py
from abc import ABC, abstractmethod


class ReportWriter(ABC):
    @abstractmethod
    def header(self):
        return "Department of Computer Science"    # an abstract method may have a body

    @abstractmethod
    def row(self, roll, name, total):
        pass


class NoticeBoardReport(ReportWriter):
    def header(self):
        return super().header() + " - Notice Board"

    def row(self, roll, name, total):
        return f"{name} ({roll}) scored {total}"


class DraftReport(ReportWriter):
    def header(self):
        return "Draft"


print(sorted(ReportWriter.__abstractmethods__))
board = NoticeBoardReport()
print(board.header())
print(board.row("07", "Rohan Patil", 169))
print(sorted(DraftReport.__abstractmethods__))
draft = DraftReport()

# campus/ch08_bind_levels.py
import tkinter as tk

root = tk.Tk()
root.title("Binding levels")
roll = tk.Entry(root, width=12)
roll.pack(padx=20, pady=15)
print("binding tags of the entry:", roll.bindtags())


def widget_level(event):
    if event.char and not event.char.isdigit():
        print(f"widget:   {event.keysym!r} refused; no other binding runs")
        return "break"
    print(f"widget:   {event.keysym!r} accepted")


def toplevel_level(event):
    print(f"toplevel: the entry now holds {roll.get()!r}")


def all_level(event):
    print("all:      seen by every widget of the application")


roll.bind("<KeyPress>", widget_level)
root.bind("<KeyPress>", toplevel_level)
root.bind_all("<KeyPress>", all_level)
root.mainloop()

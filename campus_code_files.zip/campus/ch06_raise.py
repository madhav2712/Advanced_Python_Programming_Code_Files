# campus/ch06_raise.py
def check_mark(obtained, maximum):
    if not 0 <= obtained <= maximum:
        raise ValueError(f"mark {obtained} is outside 0 to {maximum}")
    return obtained


for obtained in [81, 105, -4]:
    try:
        check_mark(obtained, 100)
        print(obtained, "accepted")
    except ValueError as error:
        print("refused:", error)


def load(entries):
    try:
        return [check_mark(int(text), 100) for text in entries]
    except ValueError:
        print("load: could not load", entries)
        raise


load(["81", "105"])

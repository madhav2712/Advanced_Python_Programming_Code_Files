# campus/ch01_mistake_del_name.py
class Student:
    def __init__(self, roll):
        self.roll = roll

    def __del__(self):
        print("finalised", self.roll)


merit_list = []
aisha = Student("12")
merit_list.append(aisha)

del aisha
print("after del aisha, the merit list still holds", merit_list[0].roll)
merit_list.clear()
print("after clearing the merit list")

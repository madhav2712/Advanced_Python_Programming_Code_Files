# campus/ch02_binding_trace.py
class ResultSheet:
    def __init__(self, title):
        self.title = title

    def add(self, student):
        return f"{self.title} <- {student}"


sheet = ResultSheet("Term I")
plain = ResultSheet.__dict__["add"]
bound = sheet.add

print(type(plain).__name__, type(bound).__name__)
print(bound.__self__ is sheet, bound.__func__ is plain)
print(bound("Aisha Khan"))
print(ResultSheet.add(sheet, "Aisha Khan"))
print("add" in sheet.__dict__, "add" in ResultSheet.__dict__)

# campus/ch01_first_class.py
class Student:
    def __init__(self, roll, name):
        self.roll = roll
        self.name = name
        self.marks = []

    def add_mark(self, mark):
        self.marks.append(mark)

    def total(self):
        return sum(self.marks)


aisha = Student("12", "Aisha Khan")
rohan = Student("07", "Rohan Patil")

aisha.add_mark(78)
aisha.add_mark(65)
rohan.add_mark(64)

print(aisha.name, aisha.total())
print(rohan.name, rohan.total())

# campus/ch09_mistake_chained.py
import pandas as pd

df = pd.read_csv("class_marks.csv", dtype={"roll": str})

# Meant: two grace marks in the lab for every student of division B.
df[df["division"] == "B"]["lab"] += 2
print(df.loc[df["division"] == "B", ["roll", "lab"]].to_string(index=False))

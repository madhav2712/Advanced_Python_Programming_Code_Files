# campus/ch07_url_parts.py
from urllib.parse import parse_qs, urlencode, urljoin, urlparse

url = "https://results.campus.example:8443/term2/marks.html?roll=12&subject=Python#lab"
parts = urlparse(url)
print("scheme:  ", parts.scheme)
print("host:    ", parts.hostname)
print("port:    ", parts.port)
print("path:    ", parts.path)
print("query:   ", parts.query)
print("fragment:", parts.fragment)
print("query as a dictionary:", parse_qs(parts.query))

print("a query built from a dictionary:", urlencode({"roll": "07", "name": "Rohan Patil"}))
print("a link resolved against the page:", urljoin(url, "../notices/exam.html"))

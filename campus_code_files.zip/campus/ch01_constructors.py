# campus/ch01_constructors.py
class Notice:
    pass


class Course:
    def __init__(self):
        self.title = "Advanced Python Programming"
        self.credits = 2


class Student:
    def __init__(self, roll, name, division="A"):
        self.roll = roll
        self.name = name
        self.division = division


n = Notice()
c = Course()
s1 = Student("12", "Aisha Khan")
s2 = Student("15", "Farhan Shaikh", "B")

print(type(n).__name__, n.__dict__)
print(c.title, c.credits)
print(s1.name, s1.division)
print(s2.name, s2.division)

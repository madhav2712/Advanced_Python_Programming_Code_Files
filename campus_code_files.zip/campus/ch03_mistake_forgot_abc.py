# campus/ch03_mistake_forgot_abc.py
from abc import abstractmethod


class ReportWriter:                       # does not inherit from ABC
    @abstractmethod
    def header(self):
        pass


report = ReportWriter()
print("created:", type(report).__name__, "| header() returned", report.header())

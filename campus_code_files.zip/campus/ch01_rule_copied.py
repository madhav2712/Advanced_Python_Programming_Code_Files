# campus/ch01_rule_copied.py
marks = {"12": 78, "07": 64}


def add_mark(roll, mark):
    if not 0 <= mark <= 100:
        print("rejected:", mark)
        return
    marks[roll] = mark


def correct_mark(roll, mark):
    marks[roll] = mark          # the range check was never copied here


add_mark("21", 150)
correct_mark("07", 150)
print(marks)

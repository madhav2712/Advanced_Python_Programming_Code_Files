# campus/ch07_read_page.py
from urllib.request import urlopen

with urlopen("http://127.0.0.1:8000/index.html", timeout=5) as response:
    print("status:", response.status, response.reason)
    print("type:  ", response.headers["Content-Type"])
    print("length:", response.headers["Content-Length"], "bytes")
    page = response.read().decode("utf-8")

print("--- source of the page ---")
print(page, end="")

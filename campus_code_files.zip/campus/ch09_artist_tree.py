# campus/ch09_artist_tree.py
import matplotlib
import matplotlib.pyplot as plt

fig, ax = plt.subplots()
bars = ax.bar(["Rohan", "Aisha", "Farhan", "Meera"], [173, 191, 92, 224])
ax.set_title("Term II totals")

print("backend:", matplotlib.get_backend(), "| canvas:", type(fig.canvas).__name__)
print("the figure's Axes:", fig.axes)

kinds = {}
for child in ax.get_children():
    kinds[type(child).__name__] = kinds.get(type(child).__name__, 0) + 1
print("children of the Axes:", kinds)
print("one bar:", bars[0])

for artist in (ax, bars[0], ax.title):
    print(type(artist).__name__, "MRO:", " -> ".join(c.__name__ for c in type(artist).__mro__))

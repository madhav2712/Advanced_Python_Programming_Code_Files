# campus/ch09_mistake_view.py
import numpy as np

register = np.array([[68, 70, 35], [78, 72, 41], [40, 30, 22], [91, 84, 49]])

# Meant: a separate set of lab marks, scaled to 100 for a chart.
lab = register[:, 2]
lab *= 2
print("lab marks for the chart:", lab)
print("the register now:", register.tolist())

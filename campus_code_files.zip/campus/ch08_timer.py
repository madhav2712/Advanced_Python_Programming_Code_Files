# campus/ch08_timer.py
import tkinter as tk

root = tk.Tk()
root.title("Exam timer")
clock = tk.Label(root, font=("Consolas", 28), width=8)
clock.pack(padx=40, pady=15)


def tick(seconds_left):
    clock.config(text=f"0:{seconds_left:02d}")
    print("seconds left:", seconds_left)
    if seconds_left == 0:
        clock.config(text="Time up", fg="red")
        print("time is up: pens down")
        return
    root.after(1000, tick, seconds_left - 1)


tick(5)
root.mainloop()

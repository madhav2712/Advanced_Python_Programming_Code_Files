# campus/ch07_web_server.py
import base64
import threading
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

PAGE = """<!DOCTYPE html>
<html>
<head><title>Campus Notice Board</title></head>
<body>
<h1>Notices</h1>
<p>Term II results will be declared on Monday.</p>
<p><a href="timetable.html">Lab timetable</a></p>
<img src="logo.gif" alt="campus logo">
</body>
</html>
"""

ROOT = Path("web_root")
ROOT.mkdir(exist_ok=True)
(ROOT / "index.html").write_bytes(PAGE.encode("utf-8"))
(ROOT / "logo.gif").write_bytes(base64.b64decode(
    "R0lGODdhBAAEAIEAAAAzZv/MAAAAAAAAACwAAAAABAAEAAAIDAABBBA4cKBAggcDAgA7"))


class CampusHandler(SimpleHTTPRequestHandler):
    def log_message(self, format, *args):
        print("server:", format % args)


handler = partial(CampusHandler, directory=str(ROOT))
server = ThreadingHTTPServer(("127.0.0.1", 8000), handler)
threading.Thread(target=server.serve_forever, daemon=True).start()
print("server: web pages on http://127.0.0.1:8000/")
input("server: press Enter to stop\n")
server.shutdown()
server.server_close()
print("server: stopped")

# campus/ch06_logging_basics.py
import logging
from pathlib import Path

logging.basicConfig(
    filename="campus.log",
    filemode="w",
    level=logging.INFO,
    format="%(asctime)s %(levelname)-8s %(name)s: %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger("campus.marks")

log.debug("parsing line %d", 1)
log.info("import started: %s", "term2_marks.txt")
log.warning("line %d skipped: mark %r is not a number", 2, "6O")
log.error("cannot open %s", "term2_lab.txt")
log.critical("the marks database is not reachable")

print(Path("campus.log").read_text(), end="")

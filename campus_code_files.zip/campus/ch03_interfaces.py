# campus/ch03_interfaces.py
from abc import ABC, abstractmethod
from collections.abc import Sized


class Exportable(ABC):                    # an interface: abstract methods only
    @abstractmethod
    def export(self):
        pass


class Printable(ABC):                     # a second interface
    @abstractmethod
    def to_text(self):
        pass


class MarkSheet(Exportable, Printable):   # one class, two interfaces
    def __init__(self, roll, marks):
        self.roll = roll
        self.marks = marks

    def export(self):
        return ",".join([self.roll] + [str(m) for m in self.marks])

    def to_text(self):
        return f"Roll {self.roll}: {self.marks}"

    def __len__(self):
        return len(self.marks)


sheet = MarkSheet("15", [38, 30, 22])
print(sheet.export())
print(sheet.to_text())
print(isinstance(sheet, Exportable), isinstance(sheet, Printable))
print(isinstance(sheet, Sized), len(sheet))
print(isinstance("Farhan", Sized), isinstance(42, Sized))

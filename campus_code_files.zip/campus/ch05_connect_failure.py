# campus/ch05_connect_failure.py
import mysql.connector

attempts = [
    ("wrong password", {"password": "campus999"}),
    ("no server on port 3307", {"password": "campus123", "port": 3307}),
]

for label, settings in attempts:
    print("attempt:", label)
    try:
        connection = mysql.connector.connect(host="localhost", user="campus", **settings)
    except mysql.connector.Error as error:
        print("  error number:", error.errno)
        print("  message     :", error.msg)
    else:
        print("  connected")
        connection.close()

# campus/ch05_campus_database.py
import mysql.connector


class SubjectMark:
    def __init__(self, subject, obtained, maximum=100):
        self.subject = subject
        self.obtained = obtained
        self.maximum = maximum


class Student:
    def __init__(self, roll, name):
        self.roll = roll
        self.name = name
        self.marks = []

    def attach(self, mark):
        self.marks.append(mark)

    def total(self):
        return sum(m.obtained for m in self.marks)

    def maximum(self):
        return sum(m.maximum for m in self.marks)


class MarksDatabase:
    def __init__(self, **settings):
        self.connection = mysql.connector.connect(**settings)

    def correct_mark(self, roll, subject, obtained):
        cursor = self.connection.cursor()
        cursor.execute(
            "UPDATE marks SET obtained = %s WHERE roll = %s AND subject = %s",
            (obtained, roll, subject),
        )
        changed = cursor.rowcount
        self.connection.commit()
        cursor.close()
        return changed

    def remove_student(self, roll):
        cursor = self.connection.cursor()
        cursor.execute("DELETE FROM marks WHERE roll = %s", (roll,))
        cursor.execute("DELETE FROM students WHERE roll = %s", (roll,))
        removed = cursor.rowcount
        self.connection.commit()
        cursor.close()
        return removed

    def load_students(self):
        cursor = self.connection.cursor()
        cursor.execute("SELECT roll, name FROM students ORDER BY roll")
        students = {roll: Student(roll, name) for roll, name in cursor.fetchall()}
        cursor.execute("SELECT roll, subject, obtained, maximum FROM marks")
        for roll, subject, obtained, maximum in cursor.fetchall():
            students[roll].attach(SubjectMark(subject, obtained, maximum))
        cursor.close()
        return list(students.values())

    def close(self):
        self.connection.close()


def grade(percent):
    if percent >= 75:
        return "Distinction"
    if percent >= 60:
        return "First Class"
    if percent >= 40:
        return "Pass"
    return "Fail"


db = MarksDatabase(host="localhost", user="campus", password="campus123", database="college")

print("Rohan's Python mark corrected, rows changed:", db.correct_mark("07", "Python", 68))
print("roll 33 removed, rows changed:", db.remove_student("33"))

print(f"{'Roll':<6}{'Name':<16}{'Total':>6}{'%':>7}  Grade")
for s in db.load_students():
    p = round(s.total() / s.maximum() * 100, 1)
    print(f"{s.roll:<6}{s.name:<16}{s.total():>6}{p:>7}  {grade(p)}")

db.close()

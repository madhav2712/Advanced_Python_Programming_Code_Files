# campus/ch07_problem_no_server.py
import socket

print("department laptop: asking the exam cell for the result of roll 12")
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(("127.0.0.1", 5052))
client.sendall(b"RESULT 12\n")
print(client.recv(1024))

# campus/ch03_duck_typing.py
class RegularStudent:
    def __init__(self, name, total):
        self.name = name
        self.total = total

    def result(self):
        return f"{self.total}/100"


class GuestAuditor:                      # shares no parent with RegularStudent
    def __init__(self, name):
        self.name = name

    def result(self):
        return "attended, not graded"


class VisitorPass:
    def __init__(self, name):
        self.name = name


def print_result(person):
    print(person.name, "->", person.result())


print_result(RegularStudent("Aisha Khan", 79))
print_result(GuestAuditor("Dr. Rao"))
print_result(VisitorPass("Parent of Rohan"))

# campus/ch04_mistake_run_not_start.py
import threading
import time


def send_notice(name):
    time.sleep(0.5)
    print(threading.current_thread().name, "sent the notice to", name)


start = time.perf_counter()
threads = [threading.Thread(target=send_notice, args=(n,)) for n in ["Aisha", "Rohan"]]
for t in threads:
    t.run()                               # should be t.start()
print(f"took {time.perf_counter() - start:.1f} s")

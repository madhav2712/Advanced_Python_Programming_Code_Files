# campus/ch06_mistake_not_exception.py
class InvalidMarkError:
    def __init__(self, message):
        self.message = message


def check_mark(obtained, maximum):
    if not 0 <= obtained <= maximum:
        raise InvalidMarkError(f"mark {obtained} is outside 0 to {maximum}")
    return obtained


print(check_mark(81, 100), "accepted")
print(check_mark(105, 100), "accepted")

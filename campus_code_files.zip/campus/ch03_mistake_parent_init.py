# campus/ch03_mistake_parent_init.py
class Learner:
    def __init__(self, roll, name):
        self.roll = roll
        self.name = name


class RegularStudent(Learner):
    def __init__(self, roll, name, internal):
        self.internal = internal


aisha = RegularStudent("12", "Aisha Khan", 21)
print(aisha.internal)
print(aisha.name)

# campus/ch03_inheritance_types.py
class Person:
    def __init__(self, name):
        self.name = name

    def greet(self):
        return f"Hello, I am {self.name}"


class Learner(Person):                    # single: Person -> Learner
    def study(self):
        return f"{self.name} is studying"


class RegularStudent(Learner):            # multilevel: Person -> Learner -> RegularStudent
    def attend_lab(self):
        return f"{self.name} is in the lab"


class ExternalStudent(Learner):           # hierarchical: Learner has two children
    def book_centre(self):
        return f"{self.name} booked an exam centre"


class Employee(Person):
    def draw_stipend(self):
        return f"{self.name} drew the stipend"


class LabAssistant(Learner, Employee):    # multiple: two parents
    pass                                  # hybrid: the whole Person diamond


aisha = RegularStudent("Aisha Khan")
kabir = ExternalStudent("Kabir Joshi")
meera = LabAssistant("Meera Iyer")

print(aisha.greet(), "|", aisha.study(), "|", aisha.attend_lab())
print(kabir.book_centre())
print(meera.study(), "|", meera.draw_stipend())
print(issubclass(RegularStudent, Person), isinstance(meera, Employee))
print([cls.__name__ for cls in LabAssistant.__mro__])

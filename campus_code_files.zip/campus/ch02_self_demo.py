# campus/ch02_self_demo.py
class SubjectMark:
    def __init__(self, subject, obtained):
        self.subject = subject
        self.obtained = obtained

    def who_am_i(self):
        print("self  is object", id(self))

    def add_grace(self, extra):
        self.obtained = self.obtained + extra


stats = SubjectMark("Statistics", 37)
print("stats is object", id(stats))
stats.who_am_i()

stats.add_grace(2)                  # Python passes stats as self
SubjectMark.add_grace(stats, 1)     # the same call, written out in full
print(stats.obtained)
print(stats.add_grace)

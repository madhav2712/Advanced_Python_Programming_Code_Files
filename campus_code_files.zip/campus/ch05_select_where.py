# campus/ch05_select_where.py
import mysql.connector

connection = mysql.connector.connect(
    host="localhost", user="campus", password="campus123", database="college"
)
cursor = connection.cursor()

find = "SELECT name, division FROM students WHERE roll = %s"

cursor.execute(find, ("21",))
print("roll 21:", cursor.fetchone())

cursor.execute(find, ("99",))
print("roll 99:", cursor.fetchone())

cursor.execute(
    "SELECT roll, subject, obtained FROM marks WHERE obtained < %s AND maximum = %s",
    (40, 100),
)
print("marks below 40 out of 100:")
row = cursor.fetchone()
while row is not None:
    print("  ", row)
    row = cursor.fetchone()

cursor.close()
connection.close()

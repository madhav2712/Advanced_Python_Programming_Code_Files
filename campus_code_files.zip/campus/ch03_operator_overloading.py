# campus/ch03_operator_overloading.py
class Score:
    def __init__(self, obtained, maximum):
        self.obtained = obtained
        self.maximum = maximum

    def percent(self):
        return round(self.obtained / self.maximum * 100, 1)

    def __add__(self, other):                 # score + score
        if not isinstance(other, Score):
            return NotImplemented
        return Score(self.obtained + other.obtained, self.maximum + other.maximum)

    def __radd__(self, other):                # 0 + score, which sum() needs
        if other == 0:
            return self
        return NotImplemented

    def __eq__(self, other):                  # score == score
        if not isinstance(other, Score):
            return NotImplemented
        return self.percent() == other.percent()

    def __lt__(self, other):                  # score < score, which sorted() needs
        if not isinstance(other, Score):
            return NotImplemented
        return self.percent() < other.percent()

    def __str__(self):                        # print(score)
        return f"{self.obtained}/{self.maximum} ({self.percent()}%)"

    def __repr__(self):                       # how a score looks inside a list
        return f"Score({self.obtained}, {self.maximum})"


theory = Score(62, 75)
practical = Score(21, 25)
print(theory + practical)
print(sum([Score(30, 40), Score(25, 35), Score(41, 50)]))
print(Score(40, 50) == Score(80, 100), Score(30, 50) < Score(35, 50))
print(sorted([Score(64, 100), Score(91, 100), Score(78, 100)], reverse=True))
print(theory + 5)

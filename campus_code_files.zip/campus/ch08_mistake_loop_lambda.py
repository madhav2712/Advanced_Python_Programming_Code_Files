# campus/ch08_mistake_loop_lambda.py
import tkinter as tk

root = tk.Tk()
root.title("Mistake 5")
for roll in ["07", "12", "15", "21"]:
    tk.Button(root, text=f"Roll {roll}",
              command=lambda: print("showing the result of roll", roll)).pack(
        side="left", padx=5, pady=10)
root.mainloop()

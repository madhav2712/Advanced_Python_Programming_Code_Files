# campus/ch09_scipy_stats.py
import pandas as pd
from scipy import stats

df = pd.read_csv("class_marks.csv", dtype={"roll": str})
percent = df[["python", "statistics", "lab"]].sum(axis=1) / 250 * 100

summary = stats.describe(percent)
print(f"n = {summary.nobs}, mean = {summary.mean:.1f}, variance = {summary.variance:.1f}, "
      f"skewness = {summary.skewness:.2f}")

r = stats.pearsonr(df["attendance"], percent)
print(f"attendance and percentage: r = {r.statistic:.3f}, p = {r.pvalue:.5f}")

line = stats.linregress(df["attendance"], percent)
print(f"fitted line: percentage = {line.slope:.2f} x attendance {line.intercept:+.1f}")
print(f"expected percentage at 75% attendance: {line.slope * 75 + line.intercept:.1f}")

a = percent[df["division"] == "A"]
b = percent[df["division"] == "B"]
t = stats.ttest_ind(a, b)
print(f"division A {a.mean():.1f}% and B {b.mean():.1f}%: t = {t.statistic:.2f}, p = {t.pvalue:.3f}")

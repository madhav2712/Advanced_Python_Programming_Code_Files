# campus/ch04_semaphore.py
import threading
import time

printers = threading.Semaphore(2)         # the lab has two printers
start = time.perf_counter()


def print_hall_ticket(name):
    with printers:
        began = time.perf_counter() - start
        time.sleep(0.5)
        print(f"{name:<6} printed, started at {began:.1f} s")


names = ["Aisha", "Rohan", "Meera", "Farhan"]
threads = [threading.Thread(target=print_hall_ticket, args=(n,)) for n in names]
for t in threads:
    t.start()
    time.sleep(0.01)
for t in threads:
    t.join()

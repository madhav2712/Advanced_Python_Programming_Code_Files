# campus/ch07_mail_refused.py
import smtplib
from email.message import EmailMessage


def notice(to):
    message = EmailMessage()
    message["Subject"] = "Parents' meeting on Saturday"
    message["From"] = "examcell@campus.example"
    message["To"] = to
    message.set_content("The parents' meeting is on Saturday at 10:00 in Hall 2.\n")
    return message


with smtplib.SMTP("127.0.0.1", 8025) as server:
    refused = server.send_message(notice("rohan.patil@campus.example, parent.patil@home.example"))
    print("first notice, refused:", refused)
    try:
        server.send_message(notice("parent.khan@home.example"))
    except smtplib.SMTPRecipientsRefused as error:
        print("second notice not sent:", error.recipients)

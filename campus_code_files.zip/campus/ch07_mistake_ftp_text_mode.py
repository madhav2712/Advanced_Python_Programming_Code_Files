# campus/ch07_mistake_ftp_text_mode.py
from ftplib import FTP

with FTP() as ftp:
    ftp.connect("127.0.0.1", 2121)
    ftp.login("campus", "campus123")
    with open("timetable_text.txt", "w", encoding="utf-8") as file:
        ftp.retrbinary("RETR timetable.txt", file.write)
    print("downloaded timetable.txt")

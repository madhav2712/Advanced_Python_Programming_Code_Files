# campus/ch06_else_finally.py
from pathlib import Path

Path("term2_good.txt").write_text("81\n68\n94\n47\n")
Path("term2_typo.txt").write_text("81\n6O\n94\n")
Path("term2_empty.txt").write_text("")


def class_average(filename):
    file = open(filename)
    try:
        marks = [int(text) for text in file.read().split()]
        average = sum(marks) / len(marks)
    except ValueError as error:
        print("  except:", error)
        average = None
    else:
        print("  else: read", len(marks), "marks")
    finally:
        file.close()
        print("  finally: file closed")
    return average


for name in ["term2_good.txt", "term2_typo.txt", "term2_empty.txt"]:
    print(name)
    try:
        print("  average:", class_average(name))
    except ZeroDivisionError as error:
        print("  the caller caught:", error)

# campus/ch05_create_tables.py
import mysql.connector

connection = mysql.connector.connect(
    host="localhost", user="campus", password="campus123", database="college"
)
cursor = connection.cursor()

# Start from empty tables each time the program runs.
cursor.execute("DROP TABLE IF EXISTS marks")
cursor.execute("DROP TABLE IF EXISTS students")

cursor.execute("""
    CREATE TABLE students (
        roll     CHAR(2)     PRIMARY KEY,
        name     VARCHAR(40) NOT NULL,
        division CHAR(1)     NOT NULL DEFAULT 'A'
    )
""")

cursor.execute("""
    CREATE TABLE marks (
        roll     CHAR(2)     NOT NULL,
        subject  VARCHAR(20) NOT NULL,
        obtained INT         NOT NULL,
        maximum  INT         NOT NULL DEFAULT 100,
        PRIMARY KEY (roll, subject),
        FOREIGN KEY (roll) REFERENCES students (roll),
        CONSTRAINT mark_in_range CHECK (obtained BETWEEN 0 AND maximum)
    )
""")

cursor.execute("SHOW TABLES")
print("tables:", [name for (name,) in cursor])

cursor.execute("DESCRIBE marks")
print(f"{'Field':<10}{'Type':<13}{'Null':<6}{'Key':<5}Default")
for field, kind, null, key, default, extra in cursor:
    print(f"{field:<10}{kind:<13}{null:<6}{key:<5}{default}")

cursor.close()
connection.close()

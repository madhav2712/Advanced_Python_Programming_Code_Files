# campus/ch01_oop_version.py
class Student:
    def __init__(self, roll, name, mark):
        self.roll = roll
        self.name = name
        self.set_mark(mark)

    def set_mark(self, mark):
        if not 0 <= mark <= 100:
            raise ValueError(f"mark out of range: {mark}")
        self.mark = mark


def by_name(student):
    return student.name


students = [
    Student("12", "Aisha Khan", 78),
    Student("07", "Rohan Patil", 64),
    Student("21", "Meera Iyer", 91),
    Student("15", "Farhan Shaikh", 55),
]
students.sort(key=by_name)

for s in students:
    print(s.roll, s.name, s.mark)

students[0].set_mark(150)

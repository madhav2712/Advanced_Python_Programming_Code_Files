# campus/ch05_connect.py
import mysql.connector

connection = mysql.connector.connect(
    host="localhost",
    user="campus",
    password="campus123",
)
print("connected:", connection.is_connected())
print("server version:", connection.server_info)
print("connection class:", type(connection).__name__)

connection.close()
print("connected after close():", connection.is_connected())
